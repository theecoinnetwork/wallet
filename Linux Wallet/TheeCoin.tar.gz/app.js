// Socket.IO connection
const socket = io();

// DOM elements
const statusEl = document.getElementById('status');
const setupSection = document.getElementById('setup-section');
const walletSection = document.getElementById('wallet-section');
const sendSection = document.getElementById('send-section');
const miningSection = document.getElementById('mining-section');
const historySection = document.getElementById('history-section');
const mnemonicSection = document.getElementById('mnemonic-section');
const purchaseSection = document.getElementById('purchase-section');
const topNav = document.getElementById('top-nav');
const loadingOverlay = document.getElementById('loading-overlay');
const toast = document.getElementById('toast');

// Wallet state
let currentWallet = null;
let currentMnemonic = null;
let miningActive = false;
let supportedCryptos = [];
let selectedCrypto = null;
let currentPayment = null;

// Utility functions
function formatTheeCoinAmount(amount) {
    // Format amount exactly like terminal version - preserve all digits
    return formatNumberWithCommas(amount);
}

function formatNumberWithCommas(number) {
    // Format numbers with thousands separators (commas) - preserve all digits like terminal version
    if (typeof number === 'string') {
        number = parseFloat(number);
    }
    if (typeof number !== 'number' || !isFinite(number)) {
        return number;
    }
    // Convert to string to preserve all digits, then format with commas
    return number.toLocaleString('en-US', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 20,
        useGrouping: true
    });
}

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    setupEventListeners();
});

// Socket events
socket.on('connect', () => {
    statusEl.textContent = 'Connected to TheeCoin Network';
    statusEl.classList.add('connected');
    
    // Check network connection status
    checkNetworkConnection();
});

socket.on('disconnect', () => {
    statusEl.textContent = 'Disconnected from TheeCoin Network';
    statusEl.classList.remove('connected');
    
    // Show connection overlay immediately when disconnected (known disconnection)
    showConnectionOverlay();
});

socket.on('miningUpdate', (miningInfo) => {
    updateMiningDisplay(miningInfo);
});

// Event listeners
function setupEventListeners() {
    // Wallet creation/loading
    document.getElementById('create-wallet-btn').onclick = showCreateWallet;
    document.getElementById('load-wallet-btn').onclick = showLoadWallet;
    
    // Load options - expandable behavior
    document.getElementById('load-mnemonic-btn').onclick = () => {
        toggleLoadOption('mnemonic-input');
        setTimeout(() => {
            document.getElementById('mnemonic').focus();
        }, 100);
    };
    document.getElementById('load-key-btn').onclick = () => {
        toggleLoadOption('private-key-input');
        setTimeout(() => {
            document.getElementById('private-key').focus();
        }, 100);
    };
    document.getElementById('load-from-file-btn').onclick = () => {
        toggleLoadOption('file-list');
        showLoadFromFile();
    };
    
    // Wallet creation
    document.getElementById('create-named-wallet-btn').onclick = createNewWallet;
    document.getElementById('cancel-create-btn').onclick = hideCreateWallet;
    
    // Mnemonic loading
    document.getElementById('load-from-mnemonic-btn').onclick = loadWalletFromMnemonic;
    document.getElementById('cancel-load-btn').onclick = () => hideLoadOption('mnemonic-input');
    
    // Private key loading
    document.getElementById('load-from-key-confirm-btn').onclick = loadWalletFromKey;
    document.getElementById('cancel-key-btn').onclick = () => hideLoadOption('private-key-input');
    
    // File loading
    document.getElementById('cancel-file-btn').onclick = () => hideLoadOption('file-list');
    
    // Wallet created section
    document.getElementById('save-wallet-btn').onclick = saveCreatedWallet;
    document.getElementById('continue-to-wallet-btn').onclick = continueToWallet;
    document.getElementById('create-another-btn').onclick = createAnotherWallet;
    
    // Copy buttons
    document.getElementById('copy-mnemonic-btn').onclick = () => copyToClipboard('created-mnemonic');
    document.getElementById('copy-private-key-btn').onclick = () => copyToClipboard('created-private-key');
    document.getElementById('copy-public-key-btn').onclick = () => copyToClipboard('created-public-key');
    document.getElementById('copy-address-btn').onclick = () => copyToClipboard('created-address');

    // Wallet operations
    document.getElementById('refresh-balance-btn').onclick = refreshBalance;
    document.getElementById('transaction-history-btn').onclick = showTransactionHistory;
    document.getElementById('show-private-info-btn').onclick = showPrivateInfo;
    document.getElementById('export-wallet-btn').onclick = showExportWallet;
    document.getElementById('close-wallet-btn').onclick = closeWallet;
    
    // Private info section
    document.getElementById('close-private-info-btn').onclick = hidePrivateInfo;
    
    // Export section
    document.getElementById('export-confirm-btn').onclick = exportWallet;
    document.getElementById('cancel-export-btn').onclick = hideExportWallet;

    // Send transactions (in send section)  
    document.getElementById('send-btn').onclick = sendTransaction;
    document.getElementById('cancel-send-btn').onclick = () => showSection('wallet');

    // Mining (in mining section)
    document.getElementById('start-mining-action-btn').onclick = startMining;
    document.getElementById('stop-mining-btn').onclick = stopMining;

    // History
    document.getElementById('close-history-btn').onclick = () => showSection('wallet');

    // Mnemonic
    document.getElementById('copy-mnemonic-display-btn').onclick = copyMnemonic;
    document.getElementById('close-mnemonic-btn').onclick = () => showSection('wallet');

    // Navigation
    document.getElementById('nav-wallet').onclick = () => {
        setActiveNav('wallet');
        showSection('wallet');
    };
    document.getElementById('nav-send').onclick = () => {
        setActiveNav('send');
        showSection('send');
    };
    document.getElementById('nav-receive').onclick = () => {
        setActiveNav('receive');
        showSection('receive');
        showReceiveInfo();
    };
    document.getElementById('nav-purchase').onclick = () => {
        setActiveNav('purchase');
        showSection('purchase');
        loadSupportedCryptos();
    };
    document.getElementById('nav-mining').onclick = () => {
        setActiveNav('mining');
        showSection('mining');
    };
    document.getElementById('nav-shopping').onclick = () => {
        setActiveNav('shopping');
        showSection('shopping');
    };

    // Purchase events
    document.getElementById('usd-amount').oninput = updatePurchaseSummary;
    document.getElementById('create-payment-btn').onclick = createCryptoPayment;
    document.getElementById('cancel-purchase-btn').onclick = () => {
        showCryptoSelection();
        loadSupportedCryptos();
    };
    document.getElementById('check-status-btn').onclick = checkPaymentStatus;
    document.getElementById('new-payment-btn').onclick = () => {
        showCryptoSelection();
        loadSupportedCryptos();
    };
    document.getElementById('close-payment-btn').onclick = () => showSection('wallet');
    
    // Receive events
    document.getElementById('copy-address-btn').onclick = () => {
        const addressText = document.getElementById('receive-address').textContent;
        if (addressText && addressText !== 'Loading...') {
            copyToClipboard('receive-address');
        }
    };
    
    // QR Scanner events
    document.getElementById('scan-qr-btn').onclick = openQRScanner;
    document.getElementById('close-scanner-btn').onclick = closeQRScanner;
    
    // Chat events
    document.getElementById('open-chat-btn').onclick = openChat;
    document.getElementById('close-chat-btn').onclick = closeChat;
    document.getElementById('send-message-btn').onclick = sendChatMessage;
    document.getElementById('chat-input').onkeypress = (e) => {
        if (e.key === 'Enter' && !e.target.disabled) {
            sendChatMessage();
        }
    };
    
    // Username setup events
    document.getElementById('set-username-btn').onclick = setUsername;
    document.getElementById('cancel-username-btn').onclick = cancelUsernameSetup;
    document.getElementById('change-username-btn').onclick = showUsernameSetup;
    document.getElementById('chat-username-input').onkeypress = (e) => {
        if (e.key === 'Enter') {
            setUsername();
        }
    };
    
    // Enhanced Shopping events
    document.getElementById('explore-listings-btn').onclick = showExploreListings;
    document.getElementById('post-listings-btn').onclick = showPostListings;
    document.getElementById('my-listings-btn').onclick = showMyListings;
    document.getElementById('browse-categories-btn').onclick = showBrowseCategories;
    document.getElementById('local-listings-btn').onclick = showLocalListings;

    // Navigation events
    document.getElementById('back-to-shopping-btn').onclick = () => showSection('shopping');
    document.getElementById('back-to-shopping-from-my-btn').onclick = () => showSection('shopping');
    document.getElementById('back-to-shopping-from-categories-btn').onclick = () => showSection('shopping');
    document.getElementById('back-to-shopping-from-local-btn').onclick = () => showSection('shopping');

    // Form events
    document.getElementById('create-first-listing-btn').onclick = () => showSection('post-listings');
    document.getElementById('add-another-listing-btn').onclick = addAnotherListingForm;
    document.getElementById('submit-listings-btn').onclick = submitListings;
    document.getElementById('cancel-listings-btn').onclick = () => showSection('shopping');

    // Search and filter events
    document.getElementById('search-btn').onclick = performSearch;
    document.getElementById('search-input').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') performSearch();
    });
    document.getElementById('clear-filters-btn').onclick = clearFilters;
    document.getElementById('search-local-btn').onclick = searchLocalListings;

    // Filter change events
    document.getElementById('category-filter').onchange = applyFilters;
    document.getElementById('location-filter').onchange = applyFilters;
    document.getElementById('price-filter').onchange = applyFilters;
    document.getElementById('condition-filter').onchange = applyFilters;
    
    // Staking events
    document.getElementById('stake-coins-btn').onclick = () => showSection('staking');
    document.getElementById('unstake-coins-btn').onclick = () => showSection('unstaking');
    document.getElementById('back-to-wallet-from-stake-btn').onclick = () => showSection('wallet');
    document.getElementById('back-to-wallet-from-unstake-btn').onclick = () => showSection('wallet');
    document.getElementById('cancel-stake-btn').onclick = () => showSection('staking');
    document.getElementById('start-staking-btn').onclick = () => showSection('staking');
    
    // Modal events
    document.getElementById('edit-listing-modal').onclick = (e) => {
        if (e.target === document.getElementById('edit-listing-modal')) {
            hideEditListingModal();
        }
    };
    
    // Escape key to close modal
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && document.getElementById('edit-listing-modal').style.display === 'flex') {
            hideEditListingModal();
        }
    });
}

// Receive functionality
function showReceiveInfo() {
    if (!currentWallet) {
        document.getElementById('receive-address').textContent = 'No wallet loaded';
        return;
    }
    
    // Display the wallet address
    document.getElementById('receive-address').textContent = currentWallet.address;
    
    // Generate QR code for the address
    generateQRCode(currentWallet.address);
}

// QR Code generation
function generateQRCode(address) {
    const qrDisplay = document.getElementById('qr-code-display');
    
    // Clear previous content
    qrDisplay.innerHTML = '';
    
    if (!address) {
        qrDisplay.innerHTML = '<div class="qr-placeholder-text">No address available</div>';
        return;
    }
    
    // Check if QRCode library is available
    if (typeof QRCode === 'undefined') {
        console.error('QRCode library not loaded');
        // Use a fallback QR code service
        const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(address)}`;
        qrDisplay.innerHTML = `<img src="${qrUrl}" alt="QR Code" style="border-radius: 8px;" width="200" height="200">`;
        return;
    }
    
    // Generate QR code using the QRCode library
    QRCode.toCanvas(qrDisplay, address, {
        width: 200,
        height: 200,
        color: {
            dark: '#000000',
            light: '#FFFFFF'
        }
    }, function (error) {
        if (error) {
            console.error('QR Code generation error:', error);
            qrDisplay.innerHTML = '<div class="qr-placeholder-text">Error generating QR code</div>';
        }
    });
}

// QR Scanner functionality
let qrScanner = null;

function openQRScanner() {
    const modal = document.getElementById('qr-scanner-modal');
    const video = document.getElementById('qr-scanner-video');
    
    modal.style.display = 'flex';
    
    // Initialize QR scanner
    qrScanner = new QrScanner(video, result => {
        // Handle successful scan
        document.getElementById('recipient').value = result.data;
        closeQRScanner();
        showToast('QR code scanned successfully!', 'success');
    }, {
        onDecodeError: error => {
            // Handle decode errors silently for better user experience
        },
        preferredCamera: 'environment' // Use back camera on mobile
    });
    
    qrScanner.start().catch(error => {
        console.error('Error starting QR scanner:', error);
        showToast('Error accessing camera. Please check permissions.', 'error');
        closeQRScanner();
    });
}

function closeQRScanner() {
    const modal = document.getElementById('qr-scanner-modal');
    modal.style.display = 'none';
    
    if (qrScanner) {
        qrScanner.stop();
        qrScanner.destroy();
        qrScanner = null;
    }
}

// Chat functionality
let chatConnected = false;
let chatUsername = null;

function openChat() {
    const modal = document.getElementById('chat-modal');
    modal.style.display = 'flex';
    
    // Check if we have a username stored
    const storedUsername = localStorage.getItem('theecoin-chat-username');
    if (storedUsername) {
        chatUsername = storedUsername;
        document.getElementById('current-username').textContent = chatUsername;
        enableChatInput();
        if (!chatConnected) {
            initializeChat();
        }
    } else {
        // Show username setup first
        showUsernameSetup();
    }
}

function closeChat() {
    const modal = document.getElementById('chat-modal');
    modal.style.display = 'none';
}

function initializeChat() {
    const statusEl = document.getElementById('chat-status');
    statusEl.textContent = 'Connecting to chat network...';
    statusEl.className = 'chat-status';
    
    // Request chat initialization from server with username
    socket.emit('initializeChat', { username: chatUsername }, (response) => {
        if (response.success) {
            chatConnected = true;
            statusEl.textContent = 'Connected to TheeCoin Chat Network';
            statusEl.className = 'chat-status connected';
            
            addChatMessage('System', 'Connected to TheeCoin chat network!', 'info');
        } else {
            statusEl.textContent = 'Failed to connect to chat network';
            statusEl.className = 'chat-status error';
            
            addChatMessage('System', 'Failed to connect to chat network. Please try again later.', 'error');
        }
    });
}

function sendChatMessage() {
    const input = document.getElementById('chat-input');
    const message = input.value.trim();
    
    if (!message) {
        return;
    }
    
    if (!chatConnected) {
        showToast('Chat not connected. Please wait...', 'error');
        return;
    }
    
    if (!chatUsername) {
        showToast('Please set a username first', 'error');
        return;
    }
    
    // Send message through socket with username
    socket.emit('sendChatMessage', { 
        message: message,
        username: chatUsername 
    }, (response) => {
        if (response.success) {
            addChatMessage('You', message, 'own');
            input.value = '';
        } else {
            showToast('Failed to send message', 'error');
        }
    });
}

function addChatMessage(sender, message, type = 'normal') {
    const messagesContainer = document.getElementById('chat-messages');
    const messageEl = document.createElement('div');
    messageEl.className = `chat-message ${type}`;
    
    const timestamp = new Date().toLocaleTimeString();
    
    if (type === 'info' || type === 'error') {
        messageEl.innerHTML = `<div class="chat-info">${message}</div>`;
    } else {
        messageEl.innerHTML = `
            <div class="message-header">${sender} - ${timestamp}</div>
            <div class="message-content">${escapeHtml(message)}</div>
        `;
    }
    
    messagesContainer.appendChild(messageEl);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Listen for incoming chat messages
socket.on('chatMessage', (data) => {
    if (data.sender && data.message) {
        addChatMessage(data.sender, data.message);
    }
});

socket.on('chatStatus', (data) => {
    const statusEl = document.getElementById('chat-status');
    if (data.connected) {
        chatConnected = true;
        statusEl.textContent = `Connected - ${data.peers || 0} peers online`;
        statusEl.className = 'chat-status connected';
    } else {
        chatConnected = false;
        statusEl.textContent = 'Disconnected from chat network';
        statusEl.className = 'chat-status error';
    }
});

// Username functionality
function validateUsername(username) {
    if (!username || typeof username !== 'string') {
        return null;
    }
    
    // Replace spaces with underscores and remove illegal characters
    let sanitized = username
        .replace(/\s+/g, '_')
        .replace(/[^a-zA-Z0-9_-]/g, '')
        .substring(0, 33);
    
    // Ensure minimum length
    if (sanitized.length < 3) {
        return null;
    }
    
    return sanitized;
}

function showUsernameSetup() {
    const usernameModal = document.getElementById('chat-username-modal');
    const chatModal = document.getElementById('chat-modal');
    
    chatModal.style.display = 'none';
    usernameModal.style.display = 'flex';
    
    // Clear previous input and error
    document.getElementById('chat-username-input').value = '';
    document.getElementById('username-error').style.display = 'none';
    
    // Focus on input
    setTimeout(() => {
        document.getElementById('chat-username-input').focus();
    }, 100);
}

function setUsername() {
    const input = document.getElementById('chat-username-input');
    const errorDiv = document.getElementById('username-error');
    const rawUsername = input.value.trim();
    
    if (!rawUsername) {
        showUsernameError('Please enter a username');
        return;
    }
    
    const validatedUsername = validateUsername(rawUsername);
    
    if (!validatedUsername) {
        if (rawUsername.length < 3) {
            showUsernameError('Username must be at least 3 characters long');
        } else if (rawUsername.length > 33) {
            showUsernameError('Username must be 33 characters or less');
        } else {
            showUsernameError('Invalid characters. Use only letters, numbers, underscore, or hyphen');
        }
        return;
    }
    
    // Save username
    chatUsername = validatedUsername;
    localStorage.setItem('theecoin-chat-username', chatUsername);
    
    // Update UI
    document.getElementById('current-username').textContent = chatUsername;
    document.getElementById('chat-username-modal').style.display = 'none';
    document.getElementById('chat-modal').style.display = 'flex';
    
    enableChatInput();
    initializeChat();
    
    showToast(`Username set to: ${chatUsername}`, 'success');
}

function showUsernameError(message) {
    const errorDiv = document.getElementById('username-error');
    errorDiv.textContent = message;
    errorDiv.style.display = 'block';
}

function cancelUsernameSetup() {
    document.getElementById('chat-username-modal').style.display = 'none';
    closeChat();
}

function enableChatInput() {
    document.getElementById('chat-input').disabled = false;
    document.getElementById('send-message-btn').disabled = false;
    document.getElementById('chat-input').placeholder = 'Type your message...';
}

// Utility functions
function showLoading(text = 'Processing...') {
    document.querySelector('.loading-text').textContent = text;
    loadingOverlay.style.display = 'flex';
}

function hideLoading() {
    loadingOverlay.style.display = 'none';
}

function updateWalletDisplay() {
    if (!currentWallet) return;
    
    try {
        // Update wallet address display
        const addressEl = document.getElementById('wallet-address');
        if (addressEl && currentWallet.address) {
            addressEl.textContent = currentWallet.address;
        }
        
        // Check if this is genesis wallet and show/hide genesis functions
        checkGenesisWallet();
        
        // Refresh balance automatically
        refreshBalance();
    } catch (error) {
        console.error('Error updating wallet display:', error);
    }
}

function showToast(message, type = 'info') {
    toast.textContent = message;
    toast.className = `toast ${type} show`;
    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

function showSection(sectionName) {
    // Hide all sections
    const sections = ['setup', 'wallet', 'send', 'receive', 'mining', 'history', 'mnemonic', 'purchase', 'wallet-created', 'private-info', 'export', 'shopping', 'explore-listings', 'post-listings', 'my-listings', 'browse-categories', 'local-listings', 'staking', 'unstaking'];
    sections.forEach(section => {
        const element = document.getElementById(`${section}-section`);
        if (element) {
            element.style.display = 'none';
        }
    });
    
    // Show requested section
    const targetSection = document.getElementById(`${sectionName}-section`);
    if (targetSection) {
        targetSection.style.display = 'block';
    }
    
    // Load specific data when certain sections are shown
    if (sectionName === 'unstaking') {
        setTimeout(() => {
            loadUserStakes();
        }, 100);
    } else if (sectionName === 'wallet') {
        // Automatically refresh balance when navigating to wallet section
        console.log('Navigating to wallet section - refreshing balance...');
        
        // Force immediate refresh
        if (currentWallet) {
            refreshBalance();
        }
        
        // Also refresh wallet details
        setTimeout(() => {
            if (currentWallet) {
                socket.emit('getWalletDetails', (response) => {
                    if (response.success && response.details) {
                        if (response.details.currentPrice) {
                            document.getElementById('current-price').textContent = `$${response.details.currentPrice.toFixed(8)}`;
                        }
                        if (response.details.totalMined !== undefined) {
                            document.getElementById('total-mined').textContent = `${formatTheeCoinAmount(response.details.totalMined)} TheeCoin`;
                        }
                        if (response.details.frozen !== undefined) {
                            document.getElementById('frozen-balance').textContent = `${formatTheeCoinAmount(response.details.frozen)} TheeCoin`;
                        }
                    }
                });
            }
        }, 500);
    }
    
    // Show/hide navigation
    if (currentWallet && !['setup', 'history', 'mnemonic', 'wallet-created', 'private-info', 'export', 'explore-listings', 'post-listings'].includes(sectionName)) {
        topNav.style.display = 'flex';
    } else {
        topNav.style.display = 'none';
    }
}



function setActiveNav(navName) {
    document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
    document.getElementById(`nav-${navName}`).classList.add('active');
}

// Connection management functions
let connectionCheckTimeout = null;

function showConnectionOverlay() {
    document.getElementById('connection-overlay').style.display = 'flex';
    document.getElementById('connection-status').textContent = 'Attempting to connect...';
}

function hideConnectionOverlay() {
    document.getElementById('connection-overlay').style.display = 'none';
    // Clear any pending connection check timeout
    if (connectionCheckTimeout) {
        clearTimeout(connectionCheckTimeout);
        connectionCheckTimeout = null;
    }
}

function checkNetworkConnection(showOverlayImmediately = false) {
    // Check if TheeCoin network is connected
    socket.emit('checkNetworkStatus', (response) => {
        if (response.success && response.connected) {
            hideConnectionOverlay();
            updateConnectionStatus('Connected to TheeCoin Network');
        } else {
            updateConnectionStatus('Not connected to TheeCoin Network');
            
            if (showOverlayImmediately) {
                // Show overlay immediately (for reconnection attempts)
                showConnectionOverlay();
            } else {
                // Only show overlay after 2 seconds if still not connected
                connectionCheckTimeout = setTimeout(() => {
                    // Double-check connection status before showing overlay
                    socket.emit('checkNetworkStatus', (recheck) => {
                        if (!recheck.success || !recheck.connected) {
                            showConnectionOverlay();
                        }
                    });
                }, 2000);
            }
            
            // Retry check every 3 seconds
            setTimeout(() => checkNetworkConnection(true), 3000);
        }
    });
}

function updateConnectionStatus(message) {
    const statusElement = document.getElementById('connection-status');
    if (statusElement) {
        statusElement.textContent = message;
    }
}

function showLoadWallet() {
    document.getElementById('load-options').style.display = 'block';
    document.getElementById('create-wallet-btn').style.display = 'none';
    document.getElementById('load-wallet-btn').style.display = 'none';
}

function hideLoadWallet() {
    document.getElementById('load-options').style.display = 'none';
    document.getElementById('create-wallet-btn').style.display = 'block';
    document.getElementById('load-wallet-btn').style.display = 'block';
    
    // Hide all expanded options
    hideAllLoadOptions();
}

// Toggle a specific load option (expand/collapse)
function toggleLoadOption(optionId) {
    // First, hide all other options
    hideAllLoadOptions();
    
    // Then show the clicked option
    const option = document.getElementById(optionId);
    if (option) {
        option.style.display = 'block';
    }
}

// Hide a specific load option
function hideLoadOption(optionId) {
    const option = document.getElementById(optionId);
    if (option) {
        option.style.display = 'none';
    }
    
    // Clear form values
    if (optionId === 'mnemonic-input') {
        document.getElementById('mnemonic').value = '';
    } else if (optionId === 'private-key-input') {
        document.getElementById('private-key').value = '';
    }
}

// Hide all load options
function hideAllLoadOptions() {
    document.getElementById('mnemonic-input').style.display = 'none';
    document.getElementById('private-key-input').style.display = 'none';
    document.getElementById('file-list').style.display = 'none';
}

// Wallet functions
function createWallet() {
    showLoading('Creating wallet...');
    
    socket.emit('createWallet', (response) => {
        hideLoading();
        
        if (response.success) {

            
            // Store the complete wallet data locally
            currentWallet = {
                address: response.wallet.address,
                publicKey: response.wallet.publicKey,
                privateKey: response.wallet.privateKey,
                mnemonic: response.wallet.mnemonic
            };
            currentMnemonic = response.wallet.mnemonic;
            

            
            // Show bottom navigation now that wallet is loaded
            document.getElementById('top-nav').style.display = 'flex';
            
            showToast('Wallet created successfully!', 'success');
            updateWalletDisplay();
            showSection('wallet');
            
            // Show mnemonic for new wallet
            setTimeout(() => {
                showToast('Please save your mnemonic phrase safely!', 'info');
            }, 1000);
        } else {
            showToast(`Error: ${response.error}`, 'error');
        }
    });
}

function loadWalletFromMnemonic() {
    const mnemonic = document.getElementById('mnemonic').value.trim();
    
    if (!mnemonic) {
        showToast('Please enter your mnemonic phrase', 'error');
        return;
    }
    
    showLoading('Loading wallet...');
    
    socket.emit('loadWallet', { mnemonic }, (response) => {
        hideLoading();
        
        if (response.success) {
            console.log('FULL load response object received:', response);
            console.log('response.wallet from load:', response.wallet);
            console.log('EXACT wallet data received from load:', {
                address: response.wallet.address,
                publicKey: response.wallet.publicKey,
                privateKey: response.wallet.privateKey,
                mnemonic: response.wallet.mnemonic
            });
            console.log('Keys present in load response:', {
                address: !!response.wallet.address,
                publicKey: !!response.wallet.publicKey,
                privateKey: !!response.wallet.privateKey,
                mnemonic: !!response.wallet.mnemonic
            });
            
            // Store the complete wallet data locally
            currentWallet = {
                address: response.wallet.address,
                publicKey: response.wallet.publicKey,
                privateKey: response.wallet.privateKey,
                mnemonic: response.wallet.mnemonic || mnemonic
            };
            currentMnemonic = response.wallet.mnemonic || mnemonic;
            
            console.log('currentWallet after load:', currentWallet);
            
            // Show bottom navigation now that wallet is loaded
            document.getElementById('top-nav').style.display = 'flex';
            
            showToast('Wallet loaded successfully!', 'success');
            updateWalletDisplay();
            showSection('wallet');
            hideLoadWallet();
        } else {
            showToast(`Error: ${response.error}`, 'error');
        }
    });
}

function updateWalletDisplay() {
    if (currentWallet) {
        document.getElementById('wallet-address').textContent = currentWallet.address;
        document.getElementById('top-nav').style.display = 'flex';
        refreshBalance();
    }
}

function refreshBalance() {
    if (!currentWallet) {
        console.log('Cannot refresh balance - no wallet loaded');
        return;
    }
    
    console.log('Refreshing balance for wallet:', currentWallet.address);
    showLoading('Refreshing balance...');
    
    socket.emit('getBalance', (response) => {
        hideLoading();
        
        if (response.success) {
            const newBalance = `${formatTheeCoinAmount(response.balance.available)} TheeCoin`;
            document.getElementById('wallet-balance').textContent = newBalance;
            console.log('Balance updated to:', newBalance);
            
            // Always show a brief success message when balance is refreshed
            showToast('Balance refreshed', 'success');
            
            // Show connection status if warning provided
            if (response.warning && !response.connected) {
                showToast(response.warning, 'warning');
            }
        } else {
            console.log('Balance refresh failed:', response.error);
            showToast(`Error: ${response.error}`, 'error');
        }
    });
    
    // Also get wallet details for price
    socket.emit('getWalletDetails', (response) => {
        if (response.success) {
            if (response.details && response.details.currentPrice) {
                document.getElementById('current-price').textContent = 
                    `$${formatNumberWithCommas(response.details.currentPrice.toFixed(4))}`;
            }
            
            // Show connection status if warning provided
            if (response.warning && !response.connected) {
                showToast(response.warning, 'warning');
            }
        }
    });
}

function sendTransaction() {
    const recipient = document.getElementById('recipient').value.trim();
    const amount = parseFloat(document.getElementById('amount').value);
    
    // Debug: Check what we have in currentWallet
    console.log('currentWallet in sendTransaction:', currentWallet);
    
    if (!recipient) {
        showToast('Please enter recipient address', 'error');
        return;
    }
    
    if (!amount || amount <= 0) {
        showToast('Please enter a valid amount', 'error');
        return;
    }
    
    showLoading('Sending transaction...');
    
    socket.emit('sendTransaction', { toAddress: recipient, amount }, (response) => {
        hideLoading();
        
        if (response.success) {
            // Show success message first
            showToast('✅ Transaction successful!', 'success');
            
            // Show countdown while updating wallet information
            let countdown = 10;
            const countdownInterval = setInterval(() => {
                showLoading(`Updating your wallet information... ${countdown}`);
                countdown--;
                
                if (countdown < 0) {
                    clearInterval(countdownInterval);
                    hideLoading();
                    
                    // Clear form and refresh
                    document.getElementById('recipient').value = '';
                    document.getElementById('amount').value = '';
                    refreshBalance();
                    showSection('wallet');
                }
            }, 1000);
            
        } else {
            showToast(`Error: ${response.error}`, 'error');
        }
    });
}

function showSendTransaction() {
    if (!currentWallet) {
        showToast('No wallet loaded', 'error');
        return;
    }
    showSection('send');
}

function showMining() {
    if (!currentWallet) {
        showToast('No wallet loaded', 'error');
        return;
    }
    showSection('mining');
}

function showPurchase() {
    if (!currentWallet) {
        showToast('No wallet loaded', 'error');
        return;
    }
    showSection('purchase');
}

function showTransactionHistory() {
    if (!currentWallet) {
        showToast('No wallet loaded', 'error');
        return;
    }
    
    showLoading('Loading transaction history...');
    
    socket.emit('getTransactionHistory', (response) => {
        hideLoading();
        
        console.log('Transaction history response:', response);
        
        if (response.success) {
            if (response.warning) {
                showToast(response.warning, 'warning');
            }
            
            let history = response.history || [];
            console.log('Transaction history received:', history);
            
            // If no history from server, create a mining entry if we have mining data locally
            if (history.length === 0) {
                // Check if there's an active mining session
                socket.emit('getMiningInfo', (miningResponse) => {
                    if (miningResponse.success && miningResponse.info && miningResponse.info.active) {
                        const miningEntry = {
                            from: '1636332663263353930336133373035663',
                            to: currentWallet.address,
                            amount: miningResponse.info.totalMined || 0,
                            timestamp: Date.now(),
                            type: 'MINED',
                            timeDisplay: 'All Mining Sessions Combined'
                        };
                        history.push(miningEntry);
                    }
                    displayTransactionHistory(history);
                });
            } else {
                displayTransactionHistory(history);
            }
            
            showSection('history');
        } else {
            showToast(`Error: ${response.error}`, 'error');
        }
    });
}

function displayTransactionHistory(transactions) {
    const listEl = document.getElementById('transaction-list');
    
    if (!transactions || transactions.length === 0) {
        listEl.innerHTML = '<div class="no-transactions">No transactions found</div>';
        return;
    }
    
    listEl.innerHTML = transactions.map(tx => {
        const txType = tx.type || 'TRANSFER';
        const isOutgoing = tx.from === currentWallet.address;

        // Determine type display based on transaction type
        let typeDisplay;
        if (txType === 'MINED') {
            typeDisplay = 'Mined';
        } else if (txType === 'REWARD') {
            typeDisplay = 'Hosting Rewards';
        } else {
            typeDisplay = isOutgoing ? 'Sent' : 'Received';
        }

        // Use timeDisplay if available (for mining/hosting summary), otherwise format timestamp
        let timeDisplay = tx.timeDisplay;
        if (!timeDisplay) {
            if (tx.timestamp && tx.timestamp !== 'GENESIS') {
                const date = new Date(tx.timestamp);
                timeDisplay = !isNaN(date.getTime()) ? date.toLocaleString() : tx.timestamp;
            } else {
                timeDisplay = 'Genesis Block Creation';
            }
        }
        
        return `
            <div class="transaction-item ${txType.toLowerCase()} ${isOutgoing ? 'sent' : 'received'}">
                <div><strong>${typeDisplay}</strong></div>
                <div>Type: ${txType}</div>
                <div>Amount: ${formatTheeCoinAmount(tx.amount)} TheeCoin</div>
                <div>To: ${tx.to}</div>
                <div>From: ${tx.from}</div>
                <div>Time: ${timeDisplay}</div>
            </div>
        `;
    }).join('');
}

function startMining() {
    showLoading('Starting mining...');
    
    console.log('Starting mining for wallet:', currentWallet);
    
    socket.emit('startMining', (response) => {
        hideLoading();
        
        console.log('Mining start response:', response);
        
        if (response.success) {
            miningActive = true;
            updateMiningUI(true);
            showToast('Mining started!', 'success');
        } else {
            showToast(`Error: ${response.error}`, 'error');
        }
    });
}

function stopMining() {
    showLoading('Stopping mining...');
    
    socket.emit('stopMining', (response) => {
        hideLoading();
        
        if (response.success) {
            miningActive = false;
            updateMiningUI(false);
            
            // Show mining results
            let message = 'Mining stopped!';
            if (response.totalMined && response.totalMined > 0) {
                message = `Mining completed! Total mined: ${formatTheeCoinAmount(response.totalMined)} TheeCoin`;
            }
            
            if (response.transactionSubmitted) {
                message += ' - Transaction submitted successfully!';
            } else if (response.totalMined > 0) {
                message += ' - Warning: Transaction submission failed, but mining data saved locally.';
            }
            
            showToast(message, 'success');
            refreshBalance();
        } else {
            showToast(`Error: ${response.error}`, 'error');
        }
    });
}

function updateMiningUI(active) {
    const statusEl = document.getElementById('mining-status');
    const startBtn = document.getElementById('start-mining-action-btn');
    const stopBtn = document.getElementById('stop-mining-btn');
    const statsEl = document.getElementById('mining-stats');
    
    if (active) {
        statusEl.textContent = 'Mining Active';
        statusEl.classList.add('active');
        startBtn.style.display = 'none';
        stopBtn.style.display = 'inline-block';
        statsEl.style.display = 'flex';
    } else {
        statusEl.textContent = 'Not Mining';
        statusEl.classList.remove('active');
        startBtn.style.display = 'inline-block';
        stopBtn.style.display = 'none';
        statsEl.style.display = 'none';
    }
}

function updateMiningDisplay(miningInfo) {
    const statusEl = document.getElementById('mining-status');
    const statsEl = document.getElementById('mining-stats');
    const hashRateEl = document.getElementById('hash-rate');
    const earningsEl = document.getElementById('mining-earnings');
    
    if (!miningInfo || !miningInfo.active) {
        // Mining stopped
        statusEl.textContent = 'Not Mining';
        statusEl.classList.remove('active');
        statsEl.style.display = 'none';
        miningActive = false;
        updateMiningUI(false);
        return;
    }
    
    statusEl.textContent = 'Mining Active';
    statusEl.classList.add('active');
    miningActive = true;
    updateMiningUI(true);
    
    // Update hash rate - use currentRate for better display
    const dailyRate = (miningInfo.currentRate || miningInfo.hashRate || 0) * 86400;
    hashRateEl.textContent = `${formatTheeCoinAmount(dailyRate)} TheeCoin/Day`;
    
    // Display current earnings
    const earnings = miningInfo.totalMined || miningInfo.earnings || 0;
    earningsEl.textContent = `${formatTheeCoinAmount(earnings)} TheeCoin`;
    
    // Show additional stats if available
    if (miningInfo.blocksFound !== undefined || miningInfo.timeRunning !== undefined) {
        let additionalInfo = '';
        if (miningInfo.blocksFound !== undefined) {
            additionalInfo += `Blocks Found: ${miningInfo.blocksFound}`;
        }
        if (miningInfo.timeRunning) {
            if (additionalInfo) additionalInfo += ' | ';
            additionalInfo += `Running: ${Math.floor(miningInfo.timeRunning / 60)}m ${miningInfo.timeRunning % 60}s`;
        }
        
        // Update or create additional info element
        let infoEl = document.getElementById('mining-additional-info');
        if (!infoEl) {
            infoEl = document.createElement('div');
            infoEl.id = 'mining-additional-info';
            infoEl.style.fontSize = '0.9em';
            infoEl.style.marginTop = '5px';
            infoEl.style.color = '#666';
            statsEl.appendChild(infoEl);
        }
        infoEl.textContent = additionalInfo;
    }
    
    statsEl.style.display = 'block';
}

function showMnemonic() {
    if (!currentMnemonic) {
        showToast('No mnemonic available', 'error');
        return;
    }
    
    document.getElementById('mnemonic-display').textContent = currentMnemonic;
    showSection('mnemonic');
}

function copyMnemonic() {
    if (!currentMnemonic) return;
    
    navigator.clipboard.writeText(currentMnemonic).then(() => {
        showToast('Mnemonic copied to clipboard!', 'success');
    }).catch(() => {
        showToast('Could not copy to clipboard', 'error');
    });
}

// Purchase functions
async function loadSupportedCryptos() {
    showLoading('Loading cryptocurrencies...');
    
    socket.emit('getSupportedCryptos', (response) => {
        hideLoading();
        
        if (response.success) {
            supportedCryptos = response.cryptos;
            displaySupportedCryptos();
        } else {
            showToast(`Error: ${response.error}`, 'error');
        }
    });
}

function displaySupportedCryptos() {
    const cryptoSelection = document.getElementById('crypto-selection');
    
    if (supportedCryptos.length === 0) {
        cryptoSelection.innerHTML = `
            <div class="crypto-unavailable">
                <h3>🚫 Crypto Payments Unavailable</h3>
                <p>Crypto payments are currently disabled due to security restrictions.</p>
                <p>This may be due to wallet tampering detection or network connectivity issues.</p>
                <p>Please ensure you are using the official TheeCoin wallet and are connected to the network.</p>
            </div>
        `;
        return;
    }
    
    cryptoSelection.innerHTML = supportedCryptos.map((crypto, index) => `
        <div class="crypto-item" onclick="selectCrypto(${index})">
            <div class="crypto-header">
                <strong>${crypto.name} (${crypto.symbol})</strong>
                <span class="crypto-rate">Minimum: ${crypto.minAmount} ${crypto.symbol}</span>
            </div>
        </div>
    `).join('');
}

function selectCrypto(index) {
    selectedCrypto = supportedCryptos[index];

    document.getElementById('selected-crypto-name').textContent =
        `${selectedCrypto.name} (${selectedCrypto.symbol})`;
    document.getElementById('crypto-rate').textContent = 'Fetching current rate...';

    showPurchaseForm();

    // Fetch the current rate for this specific crypto
    fetchCryptoRate(selectedCrypto.symbol);
}

function fetchCryptoRate(symbol) {
    socket.emit('getCryptoRate', { symbol }, (response) => {
        if (response.success) {
            // Update the selected crypto with the fetched rate
            selectedCrypto.exchangeRate = response.rate;

            // Update the display
            document.getElementById('crypto-rate').textContent =
                `Rate: $${formatNumberWithCommas(response.rate.toFixed(6))} per ${symbol}`;

            // Update purchase summary if there's an amount entered
            updatePurchaseSummary();
        } else {
            document.getElementById('crypto-rate').textContent =
                'Cannot retrieve current rate at this time. Try again later';
            selectedCrypto.exchangeRate = null;
        }
    });
}

function showPurchaseForm() {
    document.getElementById('crypto-selection').style.display = 'none';
    document.getElementById('purchase-form').style.display = 'block';
    document.getElementById('payment-details').style.display = 'none';
    
    // Clear form
    document.getElementById('usd-amount').value = '';
    document.getElementById('purchase-summary').style.display = 'none';
}

function showCryptoSelection() {
    document.getElementById('crypto-selection').style.display = 'block';
    document.getElementById('purchase-form').style.display = 'none';
    document.getElementById('payment-details').style.display = 'none';
}

function updatePurchaseSummary() {
    if (!selectedCrypto) return;

    const usdAmount = parseFloat(document.getElementById('usd-amount').value) || 0;

    if (usdAmount <= 0) {
        document.getElementById('purchase-summary').style.display = 'none';
        return;
    }

    if (!selectedCrypto.exchangeRate) {
        document.getElementById('purchase-summary').innerHTML = `
            <h4>Purchase Summary:</h4>
            <div style="color: #dc3545;">Cannot retrieve current rate at this time. Try again later</div>
        `;
        document.getElementById('purchase-summary').style.display = 'block';
        return;
    }
    
    const cryptoAmount = usdAmount / selectedCrypto.exchangeRate;
    
    // Calculate TheeCoin amount with 1 cent fee per coin after the first coin
    // Get current price from network
    let currentPrice = 0.01; // Default fallback
    try {
        const response = await fetch('/api/price/number');
        if (response.ok) {
            const priceText = await response.text();
            const priceValue = parseFloat(priceText.replace('$', ''));
            if (!isNaN(priceValue) && priceValue > 0) {
                currentPrice = priceValue;
            }
        }
    } catch (err) {
        // Use default price if network request fails
    }
    
    // Calculate TheeCoin amount: first coin at current price, additional coins at current price + 0.01
    const baseCoins = usdAmount / currentPrice;
    const additionalCoins = Math.max(0, baseCoins - 1);
    const feePerAdditionalCoin = 0.01;
    const totalFee = additionalCoins * feePerAdditionalCoin;
    const theeCoinsToReceive = baseCoins - (totalFee / currentPrice);
    
    document.getElementById('summary-usd').textContent = usdAmount.toFixed(2);
    document.getElementById('summary-crypto').textContent = cryptoAmount.toFixed(8);
    document.getElementById('summary-crypto-symbol').textContent = selectedCrypto.symbol;
    document.getElementById('summary-theecoin').textContent = formatNumberWithCommas(theeCoinsToReceive);

    // Update fee breakdown
    document.getElementById('base-price').textContent = currentPrice.toFixed(4);

    if (theeCoinsToReceive > 1) {
        const additionalCoins = theeCoinsToReceive - 1;
        const totalFee = additionalCoins * 0.01;

        document.getElementById('additional-coins').textContent = formatNumberWithCommas(additionalCoins);
        document.getElementById('total-fees').textContent = totalFee.toFixed(2);

        document.getElementById('additional-fee-info').style.display = 'block';
        document.getElementById('no-additional-fees').style.display = 'none';
    } else {
        document.getElementById('additional-fee-info').style.display = 'none';
        document.getElementById('no-additional-fees').style.display = 'block';
    }

    document.getElementById('purchase-summary').style.display = 'block';

    // Remove the "too small" error toasts - they'll be shown only when user clicks Create Payment
}

function createCryptoPayment() {
    const usdAmount = parseFloat(document.getElementById('usd-amount').value);
    
    if (!usdAmount || usdAmount < 1) {
        showToast('Please enter a valid USD amount (minimum $1)', 'error');
        return;
    }
    
    if (!selectedCrypto) {
        showToast('Please select a cryptocurrency', 'error');
        return;
    }
    
    // Check minimum amount only when creating payment
    const cryptoAmount = usdAmount / selectedCrypto.exchangeRate;
    if (cryptoAmount < selectedCrypto.minAmount) {
        showToast(`Amount too small. Minimum ${selectedCrypto.minAmount} ${selectedCrypto.symbol} required.`, 'error');
        return;
    }
    
    showLoading('Creating payment...');
    
    socket.emit('createCryptoPayment', {
        crypto: selectedCrypto.symbol,
        usdAmount: usdAmount
    }, (response) => {
        hideLoading();
        
        if (response.success) {
            currentPayment = response.payment;
            displayPaymentDetails();
            showToast('Payment created successfully!', 'success');
        } else {
            showToast(`Error: ${response.error}`, 'error');
        }
    });
}

function displayPaymentDetails() {
    document.getElementById('crypto-selection').style.display = 'none';
    document.getElementById('purchase-form').style.display = 'none';
    document.getElementById('payment-details').style.display = 'block';
    
    document.getElementById('payment-id').textContent = currentPayment.paymentId;
    document.getElementById('payment-amount').textContent = 
        `${currentPayment.amount.toFixed(8)} ${currentPayment.crypto}`;
    document.getElementById('payment-address').textContent = currentPayment.paymentAddress;
    document.getElementById('payment-expires').textContent = 
        new Date(currentPayment.expires).toLocaleString();
    document.getElementById('payment-status').textContent = 'Waiting for payment...';
    
    // Add QR code for payment address using the exact same approach as in showReceiveInfo
    const paymentAddressInfo = document.getElementById('payment-address').parentElement;
    
    // Check if QR code container already exists
    let qrContainer = document.getElementById('payment-qr-container');
    if (!qrContainer) {
        qrContainer = document.createElement('div');
        qrContainer.id = 'payment-qr-container';
        qrContainer.className = 'qr-container';
        qrContainer.style.marginTop = '15px';
        qrContainer.style.textAlign = 'center';
        qrContainer.style.width = '100%';
        
        const qrLabel = document.createElement('div');
        qrLabel.className = 'qr-label';
        qrLabel.textContent = 'Payment QR Code:';
        qrLabel.style.marginBottom = '8px';
        qrLabel.style.fontWeight = 'bold';
        qrContainer.appendChild(qrLabel);
        
        const qrCodeElement = document.createElement('div');
        qrCodeElement.id = 'payment-qr-code';
        qrCodeElement.style.margin = '0 auto';
        qrCodeElement.style.display = 'inline-block';
        qrContainer.appendChild(qrCodeElement);
        
        // Insert after the payment address element
        paymentAddressInfo.appendChild(qrContainer);
    }
    
    // Generate QR code using the exact same approach from the generateQRCode function
    const qrDisplay = document.getElementById('payment-qr-code');
    
    // Clear previous content
    qrDisplay.innerHTML = '';
    
    if (!currentPayment.paymentAddress) {
        qrDisplay.innerHTML = '<div class="qr-placeholder-text">No address available</div>';
        return;
    }
    
    // Check if QRCode library is available
    if (typeof QRCode === 'undefined') {
        console.error('QRCode library not loaded');
        // Use a fallback QR code service
        const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(currentPayment.paymentAddress)}`;
        qrDisplay.innerHTML = `<img src="${qrUrl}" alt="QR Code" style="border-radius: 8px;" width="200" height="200">`;
        return;
    }
    
    try {
        // First try the canvas method used in generateQRCode
        QRCode.toCanvas(qrDisplay, currentPayment.paymentAddress, {
            width: 200,
            height: 200,
            color: {
                dark: '#000000',
                light: '#FFFFFF'
            }
        }, function (error) {
            if (error) {
                console.error('QR Code generation error with toCanvas:', error);
                
                // Fall back to constructor method
                try {
                    qrDisplay.innerHTML = '';
                    new QRCode(qrDisplay, {
                        text: currentPayment.paymentAddress,
                        width: 200,
                        height: 200,
                        colorDark: '#000000',
                        colorLight: '#ffffff',
                        correctLevel: QRCode.CorrectLevel.H
                    });
                } catch (fallbackError) {
                    console.error('QR Code fallback also failed:', fallbackError);
                    qrDisplay.innerHTML = '<div class="qr-placeholder-text">Error generating QR code</div>';
                }
            }
        });
    } catch (mainError) {
        console.error('Main QR error:', mainError);
        // Fall back to constructor method
        try {
            qrDisplay.innerHTML = '';
            new QRCode(qrDisplay, {
                text: currentPayment.paymentAddress,
                width: 200,
                height: 200,
                colorDark: '#000000',
                colorLight: '#ffffff',
                correctLevel: QRCode.CorrectLevel.H
            });
        } catch (fallbackError) {
            console.error('Both QR methods failed:', fallbackError);
            qrDisplay.innerHTML = '<div class="qr-placeholder-text">Error generating QR code</div>';
        }
    }
}

function checkPaymentStatus() {
    if (!currentPayment) {
        showToast('No payment to check', 'error');
        return;
    }
    
    showLoading('Checking payment status...');
    
    socket.emit('checkPaymentStatus', {
        paymentId: currentPayment.paymentId
    }, (response) => {
        hideLoading();
        
        if (response.success && response.status) {
            const status = response.status;
            
            if (status.status === 'completed') {
                document.getElementById('payment-status').innerHTML = 
                    `✅ Payment Completed!<br>TheeCoin credited: ${formatNumberWithCommas(status.theeCoinsToCredit)}`;
                showToast('Payment completed! TheeCoin has been credited to your wallet.', 'success');
                
                // Refresh balance
                setTimeout(() => {
                    refreshBalance();
                }, 2000);
            } else {
                document.getElementById('payment-status').textContent = 
                    `⏳ ${status.status.charAt(0).toUpperCase() + status.status.slice(1)}`;
            }
        } else {
            showToast(`Error: ${response.error || 'Could not check payment status'}`, 'error');
        }
    });
}

// New wallet creation functions
function showCreateWallet() {
    hideAllInputSections();
    document.getElementById('wallet-name-input').style.display = 'block';
}

function hideCreateWallet() {
    document.getElementById('wallet-name-input').style.display = 'none';
}

function createNewWallet() {
    const walletName = document.getElementById('wallet-name').value.trim();
    showLoading('Creating wallet...');
    
    socket.emit('createWallet', { walletName: walletName || null }, (response) => {
        hideLoading();
        if (response.success) {
            // Show wallet creation success page
            displayWalletCreated(response.wallet);
        } else {
            showToast(`Error: ${response.error}`, 'error');
        }
    });
}

function displayWalletCreated(wallet) {
    document.getElementById('created-mnemonic').textContent = wallet.mnemonic || 'N/A';
    document.getElementById('created-private-key').textContent = wallet.privateKey || 'Not available';
    document.getElementById('created-public-key').textContent = wallet.publicKey || 'Not available';
    document.getElementById('created-address').textContent = wallet.address || 'Not available';
    
    if (wallet.filename) {
        document.getElementById('created-filename').textContent = wallet.filename;
        document.getElementById('created-filename-section').style.display = 'block';
    }
    
    // Store the complete wallet object
    currentWallet = {
        address: wallet.address,
        publicKey: wallet.publicKey,
        privateKey: wallet.privateKey,
        mnemonic: wallet.mnemonic
    };
    currentMnemonic = wallet.mnemonic;
    
    // Show bottom navigation now that wallet is loaded  
    document.getElementById('top-nav').style.display = 'flex';
    
    showSection('wallet-created');
}

function continueToWallet() {
    hideCreateWallet();
    document.getElementById('wallet-name').value = '';
    updateWalletDisplay();
    showSection('wallet');
    refreshBalance();
}

function saveCreatedWallet() {
    // Use the wallet name that was entered during creation, or generate from address
    const walletNameInput = document.getElementById('wallet-name').value.trim();
    let filename;

    if (walletNameInput) {
        // Use the user-provided name
        filename = walletNameInput.endsWith('.dat') ? walletNameInput : walletNameInput + '.dat';
    } else {
        // Fallback to address-based name
        const walletAddress = document.getElementById('created-address').textContent;
        filename = walletAddress ? `${walletAddress.substring(0, 8)}.dat` : 'wallet.dat';
    }

    showLoading('Saving wallet to /wallets folder...');
    socket.emit('exportWallet', { filename }, (response) => {
        hideLoading();
        if (response.success) {
            showToast(`Wallet saved as ${response.filename} in /wallets folder`, 'success');
            // Show the filename in the created section
            document.getElementById('created-filename-section').style.display = 'block';
            document.getElementById('created-filename').textContent = response.filename;
        } else {
            showToast(`Error saving wallet: ${response.error}`, 'error');
        }
    });
}

function createAnotherWallet() {
    hideCreateWallet();
    document.getElementById('wallet-name').value = '';
    showSection('setup');
}

// File loading functions
function showLoadFromFile() {
    hideAllInputSections();
    loadWalletFileList();
    document.getElementById('file-list').style.display = 'block';
}

function hideLoadFromFile() {
    document.getElementById('file-list').style.display = 'none';
}

function loadWalletFileList() {
    socket.emit('listWallets', (response) => {
        const filesDiv = document.getElementById('wallet-files');
        if (response.success && response.wallets.length > 0) {
            filesDiv.innerHTML = response.wallets.map(wallet => `
                <div class="wallet-file-item" onclick="loadWalletFile('${wallet.filename}')">
                    <div class="filename">${wallet.name}</div>
                    <div class="file-date">${new Date(wallet.modified).toLocaleDateString()}</div>
                </div>
            `).join('');
        } else {
            filesDiv.innerHTML = '<div class="no-files">No wallet files found</div>';
        }
    });
}

function loadWalletFile(filename) {
    showLoading('Loading wallet...');
    socket.emit('loadWalletFromFile', { filename }, (response) => {
        hideLoading();
        if (response.success) {
            currentWallet = {
                address: response.wallet.address,
                publicKey: response.wallet.publicKey,
                privateKey: response.wallet.privateKey,
                mnemonic: response.wallet.mnemonic
            };
            currentMnemonic = response.wallet.mnemonic;
            
            // Show bottom navigation now that wallet is loaded
            document.getElementById('top-nav').style.display = 'flex';
            
            hideLoadWallet();
            updateWalletDisplay();
            showSection('wallet');
            refreshBalance();
            showToast('Wallet loaded successfully!', 'success');
        } else {
            showToast(`Error: ${response.error}`, 'error');
        }
    });
}

// Private key loading functions
function showLoadFromKey() {
    hideAllInputSections();
    document.getElementById('private-key-input').style.display = 'block';
}

function hideLoadFromKey() {
    document.getElementById('private-key-input').style.display = 'none';
    document.getElementById('private-key').value = '';
}

function loadWalletFromKey() {
    const privateKey = document.getElementById('private-key').value.trim();
    if (!privateKey) {
        showToast('Please enter a private key', 'error');
        return;
    }
    
    showLoading('Loading wallet...');
    socket.emit('loadWalletFromPrivateKey', { privateKey }, (response) => {
        hideLoading();
        if (response.success) {
            currentWallet = {
                address: response.wallet.address,
                publicKey: response.wallet.publicKey,
                privateKey: response.wallet.privateKey,
                mnemonic: response.wallet.mnemonic
            };
            currentMnemonic = response.wallet.mnemonic;
            
            // Show bottom navigation now that wallet is loaded
            document.getElementById('top-nav').style.display = 'flex';
            
            hideLoadWallet();
            updateWalletDisplay();
            showSection('wallet');
            refreshBalance();
            showToast('Wallet loaded successfully!', 'success');
        } else {
            showToast(`Error: ${response.error}`, 'error');
        }
    });
}

// Private info functions
function showPrivateInfo() {
    if (!currentWallet) {
        showToast('No wallet loaded', 'error');
        return;
    }
    
    // Use local wallet data directly - this is the most reliable source
    const display = document.getElementById('private-info-display');
    
    const privateKey = currentWallet.privateKey || 'Not available';
    const publicKey = currentWallet.publicKey || 'Not available'; 
    const address = currentWallet.address || 'Not available';
    const mnemonic = currentWallet.mnemonic || currentMnemonic || null;
    
    display.innerHTML = `
        ${mnemonic && mnemonic !== 'Not available' ? `
        <div class="info-item">
            <label>🔐 Secret Recovery Phrase:</label>
            <div class="recovery-phrase" id="recovery-phrase">${mnemonic}</div>
            <button onclick="copyToClipboard('recovery-phrase')" class="btn small">Copy</button>
        </div>` : ''}
        
        <div class="info-item">
            <label>🔑 Private Key:</label>
            <div class="private-key" id="display-private-key">${privateKey}</div>
            ${privateKey !== 'Not available' ? '<button onclick="copyToClipboard(\'display-private-key\')" class="btn small">Copy</button>' : ''}
        </div>
        
        <div class="info-item">
            <label>📢 Public Key:</label>
            <div class="public-key" id="display-public-key">${publicKey}</div>
            ${publicKey !== 'Not available' ? '<button onclick="copyToClipboard(\'display-public-key\')" class="btn small">Copy</button>' : ''}
        </div>
        
        <div class="info-item">
            <label>🏠 Address:</label>
            <div class="address" id="display-address">${address}</div>
            ${address !== 'Not available' ? '<button onclick="copyToClipboard(\'display-address\')" class="btn small">Copy</button>' : ''}
        </div>
    `;
    showSection('private-info');
}

function hidePrivateInfo() {
    showSection('wallet');
}

// Export wallet functions
function showExportWallet() {
    showSection('export');
}

function hideExportWallet() {
    document.getElementById('export-filename').value = '';
    showSection('wallet');
}

function exportWallet() {
    const filename = document.getElementById('export-filename').value.trim();
    if (!filename) {
        showToast('Please enter a filename', 'error');
        return;
    }
    
    showLoading('Preparing wallet export...');
    socket.emit('exportWallet', { filename }, (response) => {
        hideLoading();
        if (response.success) {
            // Create download link
            const blob = new Blob([atob(response.data)], { type: response.mimeType });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = response.filename;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
            
            hideExportWallet();
            showToast(`Wallet downloaded as ${response.filename}`, 'success');
        } else {
            showToast(`Error: ${response.error}`, 'error');
        }
    });
}

// Helper functions
function hideAllInputSections() {
    document.getElementById('mnemonic-input').style.display = 'none';
    document.getElementById('wallet-name-input').style.display = 'none';
    document.getElementById('private-key-input').style.display = 'none';
    document.getElementById('file-list').style.display = 'none';
}

function copyToClipboard(elementId) {
    const element = document.getElementById(elementId);
    const text = element.textContent;
    
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text).then(() => {
            showToast('Copied to clipboard!', 'success');
        });
    } else {
        // Fallback for older browsers
        const textArea = document.createElement('textarea');
        textArea.value = text;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        showToast('Copied to clipboard!', 'success');
    }
}

// Enhanced Shopping functionality
let listingCounter = 1;
let currentListings = [];
let filteredListings = [];

// Enhanced shopping categories
const SHOPPING_CATEGORIES = {
    'Electronics & Technology': [
        'Smartphones & Tablets', 'Computers & Laptops', 'Gaming Consoles & Games',
        'Audio & Headphones', 'Cameras & Photography', 'Smart Home & IoT',
        'Wearable Technology', 'TV & Entertainment', 'Networking & Internet',
        'Electronic Components', 'Software & Digital Products'
    ],
    'Vehicles & Transportation': [
        'Cars & Trucks', 'Motorcycles & Scooters', 'Boats & Watercraft',
        'Aircraft & Aviation', 'Bicycles & E-bikes', 'Auto Parts & Accessories',
        'Tires & Wheels', 'Car Audio & Electronics', 'Trailers & RVs',
        'Commercial Vehicles', 'Electric Vehicles'
    ],
    'Home & Garden': [
        'Furniture & Decor', 'Appliances & Electronics', 'Tools & Hardware',
        'Garden & Outdoor', 'Kitchen & Dining', 'Bedding & Bath',
        'Lighting & Electrical', 'Flooring & Tiles', 'Paint & Supplies',
        'Security & Safety', 'Storage & Organization'
    ],
    'Fashion & Beauty': [
        'Clothing & Apparel', 'Shoes & Footwear', 'Bags & Accessories',
        'Jewelry & Watches', 'Beauty & Cosmetics', 'Hair Care & Styling',
        'Fragrances & Perfumes', 'Sunglasses & Eyewear', 'Wedding & Formal',
        'Vintage & Designer', 'Plus Size & Specialty'
    ],
    'Health & Wellness': [
        'Fitness Equipment', 'Supplements & Nutrition', 'Medical Equipment',
        'Mental Health Services', 'Alternative Medicine', 'Dental Care',
        'Vision Care', 'Personal Care', 'Therapy & Counseling',
        'Wellness Programs', 'Health Monitoring'
    ],
    'Sports & Recreation': [
        'Exercise & Fitness', 'Outdoor & Camping', 'Water Sports',
        'Winter Sports', 'Team Sports', 'Individual Sports',
        'Hunting & Fishing', 'Cycling & Running', 'Martial Arts',
        'Adventure Sports', 'Sports Memorabilia'
    ],
    'Education & Learning': [
        'Books & Textbooks', 'Online Courses', 'Tutoring & Teaching',
        'Educational Software', 'School Supplies', 'Musical Instruments',
        'Art Supplies', 'Science & Lab Equipment', 'Language Learning',
        'Professional Development', 'Certification Programs'
    ],
    'Business & Professional': [
        'Office Equipment', 'Business Services', 'Industrial Equipment',
        'Professional Tools', 'Consulting Services', 'Marketing & Advertising',
        'Legal Services', 'Accounting & Finance', 'IT Services',
        'Manufacturing Equipment', 'Wholesale & Bulk'
    ],
    'Entertainment & Media': [
        'Movies & TV Shows', 'Music & Audio', 'Books & Literature',
        'Gaming & Esports', 'Streaming Services', 'Event Tickets',
        'Musical Instruments', 'Art & Collectibles', 'Photography Services',
        'Video Production', 'Podcasting Equipment'
    ],
    'Food & Beverages': [
        'Restaurants & Dining', 'Grocery & Food Items', 'Beverages & Drinks',
        'Cooking & Baking', 'Food Delivery', 'Catering Services',
        'Specialty Foods', 'Organic & Natural', 'International Cuisine',
        'Food Equipment', 'Meal Planning'
    ],
    'Travel & Tourism': [
        'Flights & Airlines', 'Hotels & Lodging', 'Car Rentals',
        'Travel Packages', 'Tour Guides', 'Travel Insurance',
        'Luggage & Travel Gear', 'Travel Planning', 'Adventure Tours',
        'Cultural Experiences', 'Travel Photography'
    ],
    'Real Estate & Housing': [
        'Houses for Sale', 'Apartments for Rent', 'Commercial Properties',
        'Land & Lots', 'Vacation Rentals', 'Property Management',
        'Real Estate Services', 'Moving Services', 'Home Inspection',
        'Mortgage & Financing', 'Property Investment'
    ],
    'Jobs & Employment': [
        'Full-time Jobs', 'Part-time Jobs', 'Freelance & Gig Work',
        'Remote Work', 'Internships', 'Contract Work',
        'Executive Positions', 'Entry Level', 'Skilled Trades',
        'Creative Jobs', 'Technology Jobs'
    ],
    'Services & Maintenance': [
        'Home Repair & Maintenance', 'Cleaning Services', 'Landscaping & Lawn Care',
        'Pet Services', 'Personal Services', 'Event Planning',
        'Photography & Video', 'Transportation Services', 'Delivery Services',
        'Installation Services', 'Repair Services'
    ],
    'Baby & Kids': [
        'Baby Gear & Equipment', 'Toys & Games', 'Children Clothing',
        'Educational Toys', 'Baby Food & Care', 'Strollers & Car Seats',
        'Nursery Furniture', 'Childcare Services', 'Kids Activities',
        'School Supplies', 'Teen Products'
    ],
    'Pets & Animals': [
        'Dogs & Puppies', 'Cats & Kittens', 'Birds & Poultry',
        'Fish & Aquariums', 'Small Animals', 'Reptiles & Amphibians',
        'Pet Supplies', 'Pet Services', 'Livestock & Farm Animals',
        'Pet Training', 'Veterinary Services'
    ],
    'Hobbies & Crafts': [
        'Arts & Crafts Supplies', 'Model Building', 'Collecting',
        'Sewing & Textiles', 'Woodworking', 'Metalworking',
        'Electronics Projects', 'Gardening Supplies', 'Cooking & Baking',
        'Photography', 'Music & Instruments'
    ],
    'Free Items': [
        'Free Furniture', 'Free Electronics', 'Free Clothing',
        'Free Books', 'Free Household Items', 'Free Garden Items',
        'Free Building Materials', 'Free Office Supplies', 'Free Toys',
        'Free Pet Supplies', 'Free Miscellaneous'
    ],
    'Miscellaneous': [
        'Antiques & Vintage', 'Religious Items', 'Party Supplies',
        'Wedding Items', 'Seasonal Items', 'Storage Units',
        'Tickets & Vouchers', 'Gift Cards', 'Bulk Items',
        'Unusual Items', 'Everything Else'
    ]
};

function showExploreListings() {
    showSection('explore-listings');
    initializeFilters();
    loadListingsFromNetwork();
}

// Initialize filter dropdowns
function initializeFilters() {
    const categoryFilter = document.getElementById('category-filter');

    // Clear existing options except "All Categories"
    categoryFilter.innerHTML = '<option value="">All Categories</option>';

    // Add category options
    Object.keys(SHOPPING_CATEGORIES).forEach(category => {
        const option = document.createElement('option');
        option.value = category;
        option.textContent = category;
        categoryFilter.appendChild(option);
    });
}

function showPostListings() {
    // Reset forms and initialize enhanced features
    resetListingForms();
    initializeForm();
    showSection('post-listings');
}

// Initialize form features
function initializeForm() {
    // Initialize category dropdown
    const categorySelect = document.getElementById('listing-category-1');
    if (categorySelect) {
        categorySelect.innerHTML = '<option value="">Select a category...</option>';
        Object.keys(SHOPPING_CATEGORIES).forEach(category => {
            const option = document.createElement('option');
            option.value = category;
            option.textContent = category;
            categorySelect.appendChild(option);
        });

        // Add change event for subcategory
        categorySelect.onchange = () => updateSubcategories(1);
    }

    // Initialize location type change handler
    const locationTypeSelect = document.getElementById('listing-location-type-1');
    if (locationTypeSelect) {
        locationTypeSelect.onchange = () => toggleLocalFields(1);
    }

    // Initialize image upload handlers
    initializeImageUpload(1);
}

// Update subcategories based on selected category
function updateSubcategories(formNumber) {
    const categorySelect = document.getElementById(`listing-category-${formNumber}`);
    const subcategorySelect = document.getElementById(`listing-subcategory-${formNumber}`);

    if (!categorySelect || !subcategorySelect) return;

    const selectedCategory = categorySelect.value;
    subcategorySelect.innerHTML = '<option value="">Select a subcategory...</option>';

    if (selectedCategory && SHOPPING_CATEGORIES[selectedCategory]) {
        SHOPPING_CATEGORIES[selectedCategory].forEach(subcategory => {
            const option = document.createElement('option');
            option.value = subcategory;
            option.textContent = subcategory;
            subcategorySelect.appendChild(option);
        });
    }
}

// Toggle local fields visibility
function toggleLocalFields(formNumber) {
    const locationTypeSelect = document.getElementById(`listing-location-type-${formNumber}`);
    const localFields = document.getElementById(`local-fields-${formNumber}`);

    if (!locationTypeSelect || !localFields) return;

    if (locationTypeSelect.value === 'local') {
        localFields.style.display = 'block';
        document.getElementById(`listing-zipcode-${formNumber}`).required = true;
    } else {
        localFields.style.display = 'none';
        document.getElementById(`listing-zipcode-${formNumber}`).required = false;
    }
}

// Initialize image upload functionality
function initializeImageUpload(formNumber) {
    const uploadBtn = document.getElementById(`upload-file-btn-${formNumber}`);
    const addUrlBtn = document.getElementById(`add-url-btn-${formNumber}`);
    const fileInput = document.getElementById(`image-file-input-${formNumber}`);

    if (uploadBtn && fileInput) {
        uploadBtn.onclick = () => fileInput.click();
        fileInput.onchange = (e) => handleImageUpload(e, formNumber);
    }

    if (addUrlBtn) {
        addUrlBtn.onclick = () => addImageURL(formNumber);
    }
}

// Handle image file upload
async function handleImageUpload(event, formNumber) {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    const previewContainer = document.getElementById(`image-preview-${formNumber}`);
    if (!previewContainer) return;

    for (const file of files) {
        if (previewContainer.children.length >= 10) {
            showToast('Maximum 10 images allowed', 'error');
            break;
        }

        if (!file.type.startsWith('image/')) {
            showToast(`${file.name} is not an image file`, 'error');
            continue;
        }

        if (file.size > 32 * 1024 * 1024) { // 32MB limit
            showToast(`${file.name} is too large (max 32MB)`, 'error');
            continue;
        }

        try {
            showToast('Uploading image...', 'info');

            // Convert to base64
            const base64 = await fileToBase64(file);

            // Upload to imgbb
            const imageData = await uploadToImgbb(base64);

            if (imageData) {
                addImagePreview(formNumber, imageData.url, imageData.deleteUrl);
                showToast('Image uploaded successfully!', 'success');
            } else {
                showToast('Failed to upload image', 'error');
            }
        } catch (error) {
            showToast(`Error uploading ${file.name}: ${error.message}`, 'error');
        }
    }

    // Clear the file input
    event.target.value = '';
}

// Convert file to base64
function fileToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
            const base64 = reader.result.split(',')[1]; // Remove data:image/...;base64, prefix
            resolve(base64);
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}

// Upload to imgbb service
async function uploadToImgbb(base64Data) {
    const formData = new FormData();
    formData.append('key', '60cf7500721ed045c5bd165bfd46498b');
    formData.append('image', base64Data);
    formData.append('expiration', '31536000'); // 1 year

    try {
        const response = await fetch('https://api.imgbb.com/1/upload', {
            method: 'POST',
            body: formData
        });

        const data = await response.json();

        if (data.success) {
            return {
                url: data.data.url,
                deleteUrl: data.data.delete_url
            };
        } else {
            throw new Error(data.error?.message || 'Upload failed');
        }
    } catch (error) {
        throw new Error(`Upload failed: ${error.message}`);
    }
}

// Add image URL directly
function addImageURL(formNumber) {
    const url = prompt('Enter image URL:');
    if (!url || !url.trim()) return;

    const trimmedUrl = url.trim();

    // Basic URL validation
    if (!trimmedUrl.startsWith('http://') && !trimmedUrl.startsWith('https://')) {
        showToast('Please enter a valid URL starting with http:// or https://', 'error');
        return;
    }

    const previewContainer = document.getElementById(`image-preview-${formNumber}`);
    if (!previewContainer) return;

    if (previewContainer.children.length >= 10) {
        showToast('Maximum 10 images allowed', 'error');
        return;
    }

    addImagePreview(formNumber, trimmedUrl, null);
}

// Add image preview to form
function addImagePreview(formNumber, imageUrl, deleteUrl) {
    const previewContainer = document.getElementById(`image-preview-${formNumber}`);
    if (!previewContainer) return;

    const previewDiv = document.createElement('div');
    previewDiv.className = 'image-preview';
    previewDiv.innerHTML = `
        <img src="${escapeHtml(imageUrl)}" alt="Preview" loading="lazy" onerror="this.style.display='none'">
        <button type="button" class="remove-image" onclick="removeImagePreview(this, '${formNumber}')">×</button>
    `;

    // Store the URLs as data attributes
    previewDiv.dataset.imageUrl = imageUrl;
    if (deleteUrl) {
        previewDiv.dataset.deleteUrl = deleteUrl;
    }

    previewContainer.appendChild(previewDiv);
}

// Remove image preview
function removeImagePreview(button, formNumber) {
    const previewDiv = button.parentElement;
    previewDiv.remove();
}

function loadListingsFromNetwork() {
    const loadingEl = document.getElementById('listings-loading');
    const contentEl = document.getElementById('listings-content');
    const emptyEl = document.getElementById('listings-empty');

    // Show loading state
    loadingEl.style.display = 'block';
    contentEl.style.display = 'none';
    emptyEl.style.display = 'none';

    // Send API request for listings
    socket.emit('sendAPIRequest', {
        type: 'api_shopping_listings',
        data: {}
    }, (response) => {
        loadingEl.style.display = 'none';

        if (response.success && response.data.listings) {
            currentListings = response.data.listings;
            filteredListings = [...currentListings];

            if (currentListings.length > 0) {
                displayEnhancedListings(filteredListings);
                contentEl.style.display = 'block';
            } else {
                emptyEl.style.display = 'block';
            }
        } else {
            emptyEl.style.display = 'block';
        }
    });
}

// Listing display with preview/full view system
function displayEnhancedListings(listings) {
    const listEl = document.getElementById('listings-list');
    const countEl = document.getElementById('listings-count');

    if (countEl) {
        countEl.textContent = `${listings.length} listing(s) found`;
    }

    if (listings.length === 0) {
        listEl.innerHTML = '<p class="no-results">No listings match your criteria.</p>';
        return;
    }

    // Sort listings by timestamp (newest first)
    const sortedListings = [...listings].sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

    listEl.innerHTML = sortedListings.map((listing, index) => {
        return displayListingPreview(listing, index);
    }).join('');
}

// Display listing preview (compact view)
function displayListingPreview(listing, index) {
    let html = `<div class="listing-item listing-preview" onclick="showFullListing(${index})" style="cursor: pointer;">`;

    // Category badge (centered)
    if (listing.category) {
        html += `<div class="listing-category" style="text-align: center;">${escapeHtml(listing.category)}</div>`;
    }

    // Subcategory (centered, under category)
    if (listing.subcategory) {
        html += `<div style="text-align: center; font-size: 0.9rem; color: #6c757d; margin-bottom: 10px;">${escapeHtml(listing.subcategory)}</div>`;
    }

    // Title (centered, under subcategory)
    html += `<h3 style="text-align: center; margin-bottom: 10px;">${escapeHtml(listing.title)}</h3>`;

    // Price and condition (centered, under title)
    if (listing.price || listing.condition) {
        html += `<div style="text-align: center; margin-bottom: 15px;">`;
        if (listing.price) {
            let displayPrice = listing.price;
            // Add $ if it's a number and doesn't already have currency symbol
            if (/^\d+(\.\d{2})?$/.test(listing.price.trim())) {
                displayPrice = `$${listing.price}`;
            }
            html += `<span class="listing-price">${escapeHtml(displayPrice)}</span>`;
        }
        if (listing.condition) {
            html += `<span class="listing-condition">${escapeHtml(listing.condition)}</span>`;
        }
        html += `</div>`;
    }

    // First image only (if available)
    if (listing.images && listing.images.length > 0) {
        html += `<div style="text-align: center; margin-bottom: 15px;">`;
        html += `<div class="listing-image" style="display: inline-block;">`;
        html += `<img src="${escapeHtml(listing.images[0])}" alt="Listing image" style="max-width: 200px; max-height: 150px; object-fit: cover; border-radius: 4px;" loading="lazy" onerror="this.style.display='none'">`;
        html += `</div></div>`;
    }

    // Location info (centered)
    if (listing.locationType) {
        html += `<div style="text-align: center; margin-bottom: 15px;">`;
        html += `<span class="listing-location-type ${listing.locationType}">${listing.locationType.toUpperCase()}</span>`;
        if (listing.location) {
            html += ` 📍 ${escapeHtml(listing.location)}`;
        }
        if (listing.zipCode && listing.locationType === 'local') {
            html += ` 📮 ${escapeHtml(listing.zipCode)}`;
        }
        html += `</div>`;
    }

    // Posted on (centered)
    html += `<div style="text-align: center; color: #6c757d; font-size: 0.9rem;">`;
    html += `📅 Posted on: ${new Date(listing.timestamp).toLocaleString()}`;
    html += `</div>`;

    html += `</div>`;
    return html;
}

// Show full listing details
function showFullListing(index) {
    const listing = filteredListings[index];
    if (!listing) return;

    let html = `<div class="listing-item listing-full">`;

    // Back button
    html += `<div style="margin-bottom: 20px;">`;
    html += `<button onclick="goBackToListings()" class="btn secondary">← Back to Listings</button>`;
    html += `</div>`;

    // Category badge (centered)
    if (listing.category) {
        html += `<div class="listing-category" style="text-align: center;">${escapeHtml(listing.category)}</div>`;
    }

    // Subcategory (centered, under category)
    if (listing.subcategory) {
        html += `<div style="text-align: center; font-size: 0.9rem; color: #6c757d; margin-bottom: 10px;">${escapeHtml(listing.subcategory)}</div>`;
    }

    // Title (centered, under subcategory)
    html += `<h3 style="text-align: center; margin-bottom: 10px;">${escapeHtml(listing.title)}</h3>`;

    // Price and condition (centered, under title)
    if (listing.price || listing.condition) {
        html += `<div style="text-align: center; margin-bottom: 15px;">`;
        if (listing.price) {
            let displayPrice = listing.price;
            // Add $ if it's a number and doesn't already have currency symbol
            if (/^\d+(\.\d{2})?$/.test(listing.price.trim())) {
                displayPrice = `$${listing.price}`;
            }
            html += `<span class="listing-price">${escapeHtml(displayPrice)}</span>`;
        }
        if (listing.condition) {
            html += `<span class="listing-condition">${escapeHtml(listing.condition)}</span>`;
        }
        html += `</div>`;
    }

    // Images (all images, centered and stacked)
    if (listing.images && listing.images.length > 0) {
        html += `<div class="listing-images" style="text-align: center;">`;
        html += `<strong>🖼️ Images (${listing.images.length}):</strong>`;
        html += `<div class="listing-images-grid">`;
        listing.images.forEach((imageUrl, imgIndex) => {
            html += `<div class="listing-image" onclick="openImageModal('${escapeHtml(imageUrl)}')">`;
            html += `<img src="${escapeHtml(imageUrl)}" alt="Listing image ${imgIndex + 1}" loading="lazy" onerror="this.style.display='none'">`;
            html += `</div>`;
        });
        html += `</div></div>`;
    }

    // Location info (centered, under images)
    if (listing.locationType) {
        html += `<div style="text-align: center; margin-top: 15px;">`;
        html += `<span class="listing-location-type ${listing.locationType}">${listing.locationType.toUpperCase()}</span>`;
        if (listing.location) {
            html += ` 📍 ${escapeHtml(listing.location)}`;
        }
        if (listing.zipCode && listing.locationType === 'local') {
            html += ` 📮 ${escapeHtml(listing.zipCode)}`;
        }
        html += `</div>`;
    }

    // Description
    html += `<p class="listing-description" style="white-space: pre-wrap; margin-top: 20px;">${escapeHtml(listing.description)}</p>`;

    // Meta information
    html += `<div class="listing-meta">`;
    if (listing.link) {
        html += `<p><strong>🔗 Store/Product:</strong><br><a href="${escapeHtml(listing.link)}" target="_blank" rel="noopener noreferrer">${escapeHtml(listing.link)}</a></p>`;
    }
    if (listing.contact) {
        html += `<p><strong>📞 Contact:</strong><br><span style="white-space: pre-wrap;">${escapeHtml(listing.contact)}</span></p>`;
    }
    html += `<p><strong>👤 Posted by:</strong><br>${escapeHtml(listing.walletAddress)}</p>`;
    html += `<p><strong>📅 Posted on:</strong><br>${new Date(listing.timestamp).toLocaleString()}</p>`;
    if (listing.views) {
        html += `<div class="listing-views">👁️ ${listing.views} views</div>`;
    }
    html += `</div>`;

    html += `</div>`;

    // Replace the listings list with the full view
    const listEl = document.getElementById('listings-list');
    listEl.innerHTML = html;
}

// Go back to listings view
function goBackToListings() {
    displayEnhancedListings(filteredListings);
}

// Original full display function (now used for full view)
function displayEnhancedListingsOld(listings) {
    const listEl = document.getElementById('listings-list');
    const countEl = document.getElementById('listings-count');

    if (countEl) {
        countEl.textContent = `${listings.length} listing(s) found`;
    }

    if (listings.length === 0) {
        listEl.innerHTML = '<p class="no-results">No listings match your criteria.</p>';
        return;
    }

    // Sort listings by timestamp (newest first)
    const sortedListings = [...listings].sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

    // This function is now replaced by the preview/full view system
}

// Search functionality
function performSearch() {
    const searchTerm = document.getElementById('search-input').value.trim();

    if (!searchTerm) {
        showToast('Please enter a search term', 'error');
        return;
    }

    const loadingEl = document.getElementById('listings-loading');
    const contentEl = document.getElementById('listings-content');
    const emptyEl = document.getElementById('listings-empty');

    loadingEl.style.display = 'block';
    contentEl.style.display = 'none';
    emptyEl.style.display = 'none';

    socket.emit('sendAPIRequest', {
        type: 'api_shopping_search',
        data: { searchTerm }
    }, (response) => {
        loadingEl.style.display = 'none';

        if (response.success && response.data.listings) {
            filteredListings = response.data.listings;

            if (filteredListings.length > 0) {
                displayEnhancedListings(filteredListings);
                contentEl.style.display = 'block';
            } else {
                emptyEl.style.display = 'block';
            }
        } else {
            showToast('Search failed', 'error');
            emptyEl.style.display = 'block';
        }
    });
}

// Apply filters
function applyFilters() {
    const category = document.getElementById('category-filter').value;
    const locationType = document.getElementById('location-filter').value;
    const priceRange = document.getElementById('price-filter').value;
    const condition = document.getElementById('condition-filter').value;
    const zipCode = document.getElementById('zip-filter').value.trim();

    // Build filter data
    const filterData = {};
    if (category) filterData.category = category;
    if (locationType) filterData.locationType = locationType;
    if (condition) filterData.condition = condition;
    if (zipCode) filterData.zipCode = zipCode;

    // Handle price filter
    if (priceRange) {
        if (priceRange === 'free') {
            filterData.minPrice = 0;
            filterData.maxPrice = 0;
        } else if (priceRange === '0-50') {
            filterData.minPrice = 0;
            filterData.maxPrice = 50;
        } else if (priceRange === '50-200') {
            filterData.minPrice = 50;
            filterData.maxPrice = 200;
        } else if (priceRange === '200-500') {
            filterData.minPrice = 200;
            filterData.maxPrice = 500;
        } else if (priceRange === '500-1000') {
            filterData.minPrice = 500;
            filterData.maxPrice = 1000;
        } else if (priceRange === '1000+') {
            filterData.minPrice = 1000;
        }
    }

    const loadingEl = document.getElementById('listings-loading');
    const contentEl = document.getElementById('listings-content');
    const emptyEl = document.getElementById('listings-empty');

    loadingEl.style.display = 'block';
    contentEl.style.display = 'none';
    emptyEl.style.display = 'none';

    socket.emit('sendAPIRequest', {
        type: 'api_shopping_advanced_filter',
        data: filterData
    }, (response) => {
        loadingEl.style.display = 'none';

        if (response.success && response.data.listings) {
            filteredListings = response.data.listings;

            if (filteredListings.length > 0) {
                displayEnhancedListings(filteredListings);
                contentEl.style.display = 'block';
            } else {
                emptyEl.style.display = 'block';
            }
        } else {
            showToast('Filter failed', 'error');
            emptyEl.style.display = 'block';
        }
    });
}

// Clear all filters
function clearFilters() {
    document.getElementById('search-input').value = '';
    document.getElementById('category-filter').value = '';
    document.getElementById('location-filter').value = '';
    document.getElementById('price-filter').value = '';
    document.getElementById('condition-filter').value = '';
    document.getElementById('zip-filter').value = '';

    // Show all listings
    filteredListings = [...currentListings];
    displayEnhancedListings(filteredListings);

    const contentEl = document.getElementById('listings-content');
    const emptyEl = document.getElementById('listings-empty');

    if (filteredListings.length > 0) {
        contentEl.style.display = 'block';
        emptyEl.style.display = 'none';
    } else {
        contentEl.style.display = 'none';
        emptyEl.style.display = 'block';
    }
}

// Categories functionality
function showBrowseCategories() {
    showSection('browse-categories');
    loadCategories();
}

function loadCategories() {
    const loadingEl = document.getElementById('categories-loading');
    const gridEl = document.getElementById('categories-grid');

    loadingEl.style.display = 'block';
    gridEl.innerHTML = '';

    // Create category cards
    const categoryCards = Object.keys(SHOPPING_CATEGORIES).map(category => {
        // Count listings in this category (from current listings)
        const count = currentListings.filter(listing => listing.category === category).length;

        return `
            <div class="category-card" onclick="browseCategory('${escapeHtml(category)}')">
                <h3>${escapeHtml(category)}</h3>
                <div class="item-count">${count} item(s)</div>
            </div>
        `;
    }).join('');

    setTimeout(() => {
        loadingEl.style.display = 'none';
        gridEl.innerHTML = categoryCards;
    }, 500);
}

function browseCategory(category) {
    // Set the category filter and go to explore listings
    showSection('explore-listings');
    initializeFilters();

    // Set the category filter
    document.getElementById('category-filter').value = category;

    // Apply the filter
    applyFilters();
}

// Local listings functionality
function showLocalListings() {
    showSection('local-listings');
}

function searchLocalListings() {
    const zipCode = document.getElementById('local-zip-input').value.trim();

    if (!zipCode) {
        showToast('Please enter a ZIP code', 'error');
        return;
    }

    const loadingEl = document.getElementById('local-listings-loading');
    const contentEl = document.getElementById('local-listings-content');
    const emptyEl = document.getElementById('local-listings-empty');

    loadingEl.style.display = 'block';
    contentEl.style.display = 'none';
    emptyEl.style.display = 'none';

    socket.emit('sendAPIRequest', {
        type: 'api_shopping_filter_location',
        data: {
            locationType: 'local',
            zipCode: zipCode
        }
    }, (response) => {
        loadingEl.style.display = 'none';

        if (response.success && response.data.listings) {
            const localListings = response.data.listings;

            if (localListings.length > 0) {
                displayLocalListings(localListings, zipCode);
                contentEl.style.display = 'block';
            } else {
                emptyEl.style.display = 'block';
            }
        } else {
            showToast('Failed to search local listings', 'error');
            emptyEl.style.display = 'block';
        }
    });
}

function displayLocalListings(listings, zipCode) {
    const countEl = document.getElementById('local-listings-count');
    const listEl = document.getElementById('local-listings-list');

    countEl.textContent = `${listings.length} local listing(s) found near ${zipCode}`;

    // Store listings for full view access
    filteredListings = listings;

    // Use the preview system
    listEl.innerHTML = listings.map((listing, index) => {
        return displayListingPreview(listing, index);
    }).join('');
}

// Image modal functionality
function openImageModal(imageUrl) {
    // Create a simple image modal
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.8);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 10000;
        cursor: pointer;
    `;

    const img = document.createElement('img');
    img.src = imageUrl;
    img.style.cssText = `
        max-width: 90%;
        max-height: 90%;
        object-fit: contain;
    `;

    modal.appendChild(img);
    document.body.appendChild(modal);

    // Close on click
    modal.onclick = () => {
        document.body.removeChild(modal);
    };

    // Close on escape key
    const closeOnEscape = (e) => {
        if (e.key === 'Escape') {
            document.body.removeChild(modal);
            document.removeEventListener('keydown', closeOnEscape);
        }
    };
    document.addEventListener('keydown', closeOnEscape);
}

function addAnotherListingForm() {
    listingCounter++;
    const container = document.getElementById('listings-form-container');

    const newForm = document.createElement('div');
    newForm.className = 'listing-form';
    newForm.id = `listing-form-${listingCounter}`;
    newForm.style.textAlign = 'center';
    newForm.innerHTML = `
        <h3 style="text-align: center;">Listing ${listingCounter} <button class="remove-listing-btn" onclick="removeListing(${listingCounter})">✕</button></h3>

        <!-- Basic Information -->
        <div class="form-section">
            <h4 style="text-align: center;">📋 Basic Information</h4>
            <div class="input-group" style="text-align: center;">
                <label for="listing-title-${listingCounter}" style="text-align: center; display: block;">Title (max 100 characters):</label>
                <input type="text" id="listing-title-${listingCounter}" maxlength="100" placeholder="Enter listing title..." required style="text-align: center; margin: 0 auto; display: block;">
            </div>
            <div class="input-group" style="text-align: center;">
                <label for="listing-description-${listingCounter}" style="text-align: center; display: block;">Description (max 500 characters):</label>
                <textarea id="listing-description-${listingCounter}" rows="4" maxlength="500" placeholder="Enter description..." style="white-space: pre-wrap; text-align: center; margin: 0 auto; display: block;" required></textarea>
            </div>
        </div>

        <!-- Category Selection -->
        <div class="form-section">
            <h4 style="text-align: center;">📂 Category</h4>
            <div class="input-group" style="text-align: center;">
                <label for="listing-category-${listingCounter}" style="text-align: center; display: block;">Category:</label>
                <select id="listing-category-${listingCounter}" required style="text-align: center; margin: 0 auto; display: block;">
                    <option value="">Select a category...</option>
                </select>
            </div>
            <div class="input-group" style="text-align: center;">
                <label for="listing-subcategory-${listingCounter}" style="text-align: center; display: block;">Subcategory (optional):</label>
                <select id="listing-subcategory-${listingCounter}" style="text-align: center; margin: 0 auto; display: block;">
                    <option value="">Select a subcategory...</option>
                </select>
            </div>
        </div>

        <!-- Price and Condition -->
        <div class="form-section">
            <h4 style="text-align: center;">💰 Price & Condition</h4>
            <div class="input-row" style="text-align: center;">
                <div class="input-group" style="text-align: center;">
                    <label for="listing-price-${listingCounter}" style="text-align: center; display: block;">Price (max 50 characters):</label>
                    <input type="text" id="listing-price-${listingCounter}" maxlength="50" placeholder="e.g., $50, Free, Best Offer" style="text-align: center; margin: 0 auto; display: block;">
                </div>
                <div class="input-group" style="text-align: center;">
                    <label for="listing-condition-${listingCounter}" style="text-align: center; display: block;">Condition:</label>
                    <select id="listing-condition-${listingCounter}" style="text-align: center; margin: 0 auto; display: block;">
                        <option value="">Select condition...</option>
                        <option value="New">New</option>
                        <option value="Like New">Like New</option>
                        <option value="Good">Good</option>
                        <option value="Fair">Fair</option>
                        <option value="Poor">Poor</option>
                        <option value="For Parts">For Parts</option>
                        <option value="Not Applicable">Not Applicable</option>
                    </select>
                </div>
            </div>
        </div>

        <!-- Location Information -->
        <div class="form-section">
            <h4 style="text-align: center;">🌍 Location</h4>
            <div class="input-group" style="text-align: center;">
                <label for="listing-location-type-${listingCounter}" style="text-align: center; display: block;">Location Type:</label>
                <select id="listing-location-type-${listingCounter}" required style="text-align: center; margin: 0 auto; display: block;">
                    <option value="">Select location type...</option>
                    <option value="local">Local (in-person pickup/delivery)</option>
                    <option value="remote">Remote (shipping/digital)</option>
                </select>
            </div>
            <div class="input-group" id="local-fields-${listingCounter}" style="display: none; text-align: center;">
                <label for="listing-zipcode-${listingCounter}" style="text-align: center; display: block;">ZIP Code:</label>
                <input type="text" id="listing-zipcode-${listingCounter}" maxlength="20" placeholder="Enter ZIP code" style="text-align: center; margin: 0 auto; display: block;">
            </div>
            <div class="input-group" style="text-align: center;">
                <label for="listing-location-${listingCounter}" style="text-align: center; display: block;">Location/Shipping Info (optional):</label>
                <input type="text" id="listing-location-${listingCounter}" maxlength="100" placeholder="City, area, or shipping details" style="text-align: center; margin: 0 auto; display: block;">
            </div>
        </div>

        <!-- Images -->
        <div class="form-section">
            <h4 style="text-align: center;">🖼️ Images (up to 10)</h4>
            <div class="image-upload-container" style="text-align: center;">
                <div class="upload-options" style="text-align: center;">
                    <button type="button" id="upload-file-btn-${listingCounter}" class="btn secondary">📁 Upload Image File</button>
                    <button type="button" id="add-url-btn-${listingCounter}" class="btn secondary">🔗 Add Image URL</button>
                </div>
                <input type="file" id="image-file-input-${listingCounter}" accept="image/*" style="display: none;" multiple>
                <div id="image-preview-${listingCounter}" class="image-preview-container" style="text-align: center;"></div>
            </div>
        </div>

        <!-- Additional Information -->
        <div class="form-section">
            <h4 style="text-align: center;">📋 Additional Information</h4>
            <div class="input-group" style="text-align: center;">
                <label for="listing-tags-${listingCounter}" style="text-align: center; display: block;">Tags (comma-separated, optional):</label>
                <input type="text" id="listing-tags-${listingCounter}" placeholder="e.g., vintage, collectible, rare" style="text-align: center; margin: 0 auto; display: block;">
            </div>
            <div class="input-group" style="text-align: center;">
                <label for="listing-link-${listingCounter}" style="text-align: center; display: block;">Store/Product Link (optional):</label>
                <input type="url" id="listing-link-${listingCounter}" maxlength="300" placeholder="https://example.com/your-store" style="text-align: center; margin: 0 auto; display: block;">
            </div>
            <div class="input-group" style="text-align: center;">
                <label for="listing-contact-${listingCounter}" style="text-align: center; display: block;">Contact Information (optional):</label>
                <textarea id="listing-contact-${listingCounter}" rows="3" maxlength="200" placeholder="Email, phone, social media, etc." style="white-space: pre-wrap; text-align: center; margin: 0 auto; display: block;"></textarea>
            </div>
        </div>
    `;

    container.appendChild(newForm);

    // Initialize the new form's functionality
    initializeListingForm(listingCounter);
}

// Initialize functionality for a specific listing form
function initializeListingForm(formNumber) {
    // Initialize category dropdown
    const categorySelect = document.getElementById(`listing-category-${formNumber}`);
    if (categorySelect) {
        // Populate categories
        Object.keys(SHOPPING_CATEGORIES).forEach(category => {
            const option = document.createElement('option');
            option.value = category;
            option.textContent = category;
            categorySelect.appendChild(option);
        });

        // Add change event for subcategory
        categorySelect.onchange = () => updateSubcategories(formNumber);
    }

    // Initialize location type change handler
    const locationTypeSelect = document.getElementById(`listing-location-type-${formNumber}`);
    if (locationTypeSelect) {
        locationTypeSelect.onchange = () => toggleLocalFields(formNumber);
    }

    // Initialize image upload handlers
    const uploadBtn = document.getElementById(`upload-file-btn-${formNumber}`);
    const addUrlBtn = document.getElementById(`add-url-btn-${formNumber}`);
    const fileInput = document.getElementById(`image-file-input-${formNumber}`);

    if (uploadBtn && fileInput) {
        uploadBtn.onclick = () => fileInput.click();
        fileInput.onchange = (e) => handleImageUpload(e, formNumber);
    }

    if (addUrlBtn) {
        addUrlBtn.onclick = () => addImageURL(formNumber);
    }
}

// Update subcategories for specific form
function updateSubcategories(formNumber) {
    const categorySelect = document.getElementById(`listing-category-${formNumber}`);
    const subcategorySelect = document.getElementById(`listing-subcategory-${formNumber}`);

    if (!categorySelect || !subcategorySelect) return;

    const selectedCategory = categorySelect.value;
    subcategorySelect.innerHTML = '<option value="">Select a subcategory...</option>';

    if (selectedCategory && SHOPPING_CATEGORIES[selectedCategory]) {
        SHOPPING_CATEGORIES[selectedCategory].forEach(subcategory => {
            const option = document.createElement('option');
            option.value = subcategory;
            option.textContent = subcategory;
            subcategorySelect.appendChild(option);
        });
    }
}

// Toggle local fields for specific form
function toggleLocalFields(formNumber) {
    const locationTypeSelect = document.getElementById(`listing-location-type-${formNumber}`);
    const localFields = document.getElementById(`local-fields-${formNumber}`);
    const zipcodeInput = document.getElementById(`listing-zipcode-${formNumber}`);

    if (!locationTypeSelect || !localFields || !zipcodeInput) return;

    if (locationTypeSelect.value === 'local') {
        localFields.style.display = 'block';
        zipcodeInput.required = true;
    } else {
        localFields.style.display = 'none';
        zipcodeInput.required = false;
    }
}

function removeListing(formNumber) {
    const form = document.getElementById(`listing-form-${formNumber}`);
    if (form) {
        form.remove();
    }
}

function resetListingForms() {
    const container = document.getElementById('listings-form-container');
    
    // Remove all forms except the first one
    container.innerHTML = `
        <div class="listing-form" id="listing-form-1">
            <h3>Listing 1</h3>
            <div class="input-group">
                <label for="listing-title-1">Title (max 100 characters):</label>
                <input type="text" id="listing-title-1" maxlength="100" placeholder="Enter listing title...">
            </div>
            <div class="input-group">
                <label for="listing-description-1">Description (max 500 characters):</label>
                <textarea id="listing-description-1" rows="4" maxlength="500" placeholder="Enter description..." style="white-space: pre-wrap;"></textarea>
            </div>
            <div class="input-group">
                <label for="listing-link-1">Store/Product Link (optional):</label>
                <input type="url" id="listing-link-1" maxlength="300" placeholder="https://example.com/your-store">
            </div>
            <div class="input-group">
                <label for="listing-contact-1">Contact Information (optional):</label>
                <textarea id="listing-contact-1" rows="3" maxlength="200" placeholder="Email, phone, social media, etc." style="white-space: pre-wrap;"></textarea>
            </div>
        </div>
    `;
    
    listingCounter = 1;
}

// Submit function for new listing format
function submitListings() {
    const forms = document.querySelectorAll('.listing-form');
    const listings = [];

    // Collect all enhanced form data
    for (const form of forms) {
        const formNumber = form.id.split('-')[2];

        // Basic fields
        const title = document.getElementById(`listing-title-${formNumber}`)?.value.trim() || '';
        const description = document.getElementById(`listing-description-${formNumber}`)?.value.trim() || '';
        const category = document.getElementById(`listing-category-${formNumber}`)?.value || '';
        const subcategory = document.getElementById(`listing-subcategory-${formNumber}`)?.value || '';
        const price = document.getElementById(`listing-price-${formNumber}`)?.value.trim() || '';
        const condition = document.getElementById(`listing-condition-${formNumber}`)?.value || '';
        const locationType = document.getElementById(`listing-location-type-${formNumber}`)?.value || '';
        const location = document.getElementById(`listing-location-${formNumber}`)?.value.trim() || '';
        const zipCode = document.getElementById(`listing-zipcode-${formNumber}`)?.value.trim() || '';
        const tags = document.getElementById(`listing-tags-${formNumber}`)?.value.trim() || '';
        const link = document.getElementById(`listing-link-${formNumber}`)?.value.trim() || '';
        const contact = document.getElementById(`listing-contact-${formNumber}`)?.value.trim() || '';

        // Validate required fields
        if (!title || !description || !category || !locationType) {
            showToast(`Please complete all required fields in listing ${formNumber}`, 'error');
            return;
        }

        // Validate local listings require ZIP code
        if (locationType === 'local' && !zipCode) {
            showToast(`ZIP code is required for local listings (listing ${formNumber})`, 'error');
            return;
        }

        // Collect images
        const imagePreviewContainer = document.getElementById(`image-preview-${formNumber}`);
        const images = [];
        const imageDeleteUrls = [];

        if (imagePreviewContainer) {
            const previews = imagePreviewContainer.querySelectorAll('.image-preview');
            previews.forEach(preview => {
                const imageUrl = preview.dataset.imageUrl;
                const deleteUrl = preview.dataset.deleteUrl;
                if (imageUrl) {
                    images.push(imageUrl);
                    if (deleteUrl) {
                        imageDeleteUrls.push(deleteUrl);
                    }
                }
            });
        }

        // Process tags
        const tagsArray = tags ? tags.split(',').map(tag => tag.trim()).filter(tag => tag.length > 0) : [];

        // Build Listing object
        const listing = {
            title,
            description,
            category,
            subcategory,
            price,
            condition,
            locationType,
            location,
            zipCode,
            images,
            imageDeleteUrls,
            tags: tagsArray,
            link,
            contact,
            version: 2
        };

        listings.push(listing);
    }

    if (listings.length === 0) {
        showToast('Please add at least one complete listing', 'error');
        return;
    }

    showLoading(`Submitting ${listings.length} Listing(s)...`);

    let submitted = 0;
    let errors = 0;

    const submitListing = (index) => {
        if (index >= listings.length) {
            hideLoading();
            if (submitted > 0) {
                showToast(`${submitted}/${listings.length} listing(s) posted successfully!`, 'success');
                resetListingForms();
                if (errors === 0) {
                    showSection('shopping');
                }
            } else {
                showToast('Failed to post any listings', 'error');
            }
            return;
        }

        const listing = listings[index];

        socket.emit('sendAPIRequest', {
            type: 'api_shopping_post_listing',
            data: {
                ...listing,
                walletAddress: currentWallet.address
            }
        }, (response) => {
            if (response.success) {
                submitted++;
            } else {
                errors++;
                console.error(`Failed to post listing: ${response.error}`);
            }
            submitListing(index + 1);
        });
    };

    submitListing(0);
}

// Reset Listing forms
function resetListingForms() {
    const container = document.getElementById('listings-form-container');

    // Remove all additional forms (keep only the first one)
    const forms = container.querySelectorAll('.listing-form');
    for (let i = 1; i < forms.length; i++) {
        forms[i].remove();
    }

    // Reset the first form values
    const firstForm = document.getElementById('listing-form-1');
    if (firstForm) {
        // Reset all input fields
        const inputs = firstForm.querySelectorAll('input, textarea, select');
        inputs.forEach(input => {
            if (input.type === 'checkbox' || input.type === 'radio') {
                input.checked = false;
            } else {
                input.value = '';
            }
        });

        // Clear image previews
        const imagePreview = document.getElementById('image-preview-1');
        if (imagePreview) {
            imagePreview.innerHTML = '';
        }

        // Hide local fields
        const localFields = document.getElementById('local-fields-1');
        if (localFields) {
            localFields.style.display = 'none';
        }
    }

    listingCounter = 1;

    // Reinitialize the form
    initializeForm();
}

// Show My Listings section
function showMyListings() {
    if (!currentWallet) {
        showToast('Please load a wallet first', 'error');
        return;
    }
    
    showSection('my-listings');
    loadMyListings();
}

// Load user's listings
function loadMyListings() {
    const loadingEl = document.getElementById('my-listings-loading');
    const contentEl = document.getElementById('my-listings-content');
    const emptyEl = document.getElementById('my-listings-empty');
    const listEl = document.getElementById('my-listings-list');
    
    // Show loading state
    loadingEl.style.display = 'block';
    contentEl.style.display = 'none';
    emptyEl.style.display = 'none';
    
    socket.emit('sendAPIRequest', {
        type: 'api_shopping_listings',
        data: {}
    }, (response) => {
        loadingEl.style.display = 'none';
        
        if (response.success && response.data && response.data.listings) {
            // Filter to only user's listings
            const myListings = response.data.listings.filter(listing => 
                listing.walletAddress === currentWallet.address || listing.postedBy === currentWallet.address
            );
            
            if (myListings.length === 0) {
                emptyEl.style.display = 'block';
            } else {
                contentEl.style.display = 'block';
                displayMyListings(myListings);
            }
        } else {
            showToast('Failed to load your listings', 'error');
            emptyEl.style.display = 'block';
        }
    });
}

// Display user's listings with preview/full view system
function displayMyListings(listings) {
    const listEl = document.getElementById('my-listings-list');

    if (listings.length === 0) {
        listEl.innerHTML = '<p>No listings found.</p>';
        return;
    }

    // Store listings for full view access
    currentMyListings = listings;

    // Sort listings by timestamp (newest first)
    const sortedListings = [...listings].sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

    listEl.innerHTML = sortedListings.map((listing, index) => {
        return displayMyListingPreview(listing, index);
    }).join('');
}

// Display my listing preview (compact view)
function displayMyListingPreview(listing, index) {
    let html = `<div class="listing-item listing-preview my-listing-item" onclick="showMyFullListing(${index})" style="cursor: pointer;">`;

    // Category badge (centered)
    if (listing.category) {
        html += `<div class="listing-category" style="text-align: center;">${escapeHtml(listing.category)}</div>`;
    }

    // Subcategory (centered, under category)
    if (listing.subcategory) {
        html += `<div style="text-align: center; font-size: 0.9rem; color: #6c757d; margin-bottom: 10px;">${escapeHtml(listing.subcategory)}</div>`;
    }

    // Title (centered, under subcategory)
    html += `<h3 style="text-align: center; margin-bottom: 10px;">${escapeHtml(listing.title)}</h3>`;

    // Price and condition (centered, under title)
    if (listing.price || listing.condition) {
        html += `<div style="text-align: center; margin-bottom: 15px;">`;
        if (listing.price) {
            let displayPrice = listing.price;
            // Add $ if it's a number and doesn't already have currency symbol
            if (/^\d+(\.\d{2})?$/.test(listing.price.trim())) {
                displayPrice = `$${listing.price}`;
            }
            html += `<span class="listing-price">${escapeHtml(displayPrice)}</span>`;
        }
        if (listing.condition) {
            html += `<span class="listing-condition">${escapeHtml(listing.condition)}</span>`;
        }
        html += `</div>`;
    }

    // First image only (if available)
    if (listing.images && listing.images.length > 0) {
        html += `<div style="text-align: center; margin-bottom: 15px;">`;
        html += `<div class="listing-image" style="display: inline-block;">`;
        html += `<img src="${escapeHtml(listing.images[0])}" alt="Listing image" style="max-width: 200px; max-height: 150px; object-fit: cover; border-radius: 4px;" loading="lazy" onerror="this.style.display='none'">`;
        html += `</div></div>`;
    }

    // Location info (centered)
    if (listing.locationType) {
        html += `<div style="text-align: center; margin-bottom: 15px;">`;
        html += `<span class="listing-location-type ${listing.locationType}">${listing.locationType.toUpperCase()}</span>`;
        if (listing.location) {
            html += ` 📍 ${escapeHtml(listing.location)}`;
        }
        if (listing.zipCode && listing.locationType === 'local') {
            html += ` 📮 ${escapeHtml(listing.zipCode)}`;
        }
        html += `</div>`;
    }

    // Posted on (centered)
    html += `<div style="text-align: center; margin-bottom: 15px; color: #6c757d; font-size: 0.9rem;">`;
    html += `<div>Posted:</div>`;
    html += `<div>${new Date(listing.timestamp).toLocaleString()}</div>`;
    html += `</div>`;

    // Edit and Delete buttons (centered, side by side)
    html += `<div style="text-align: center; margin-top: 15px;">`;
    html += `<button onclick="event.stopPropagation(); showEditListingDialog(${JSON.stringify(listing).replace(/"/g, '&quot;')})" class="btn secondary" style="margin-right: 10px;">Edit</button>`;
    html += `<button onclick="event.stopPropagation(); deleteListing('${listing.id}')" class="btn danger">Delete</button>`;
    html += `</div>`;

    html += `</div>`;
    return html;
}

// Show full my listing details
let currentMyListings = [];

function showMyFullListing(index) {
    const listing = currentMyListings[index];
    if (!listing) return;

    let html = `<div class="listing-item listing-full my-listing-item">`;

    // Back button
    html += `<div style="margin-bottom: 20px;">`;
    html += `<button onclick="goBackToMyListings()" class="btn secondary">← Back to My Listings</button>`;
    html += `</div>`;

    // Category badge (centered)
    if (listing.category) {
        html += `<div class="listing-category" style="text-align: center;">${escapeHtml(listing.category)}</div>`;
    }

    // Subcategory (centered, under category)
    if (listing.subcategory) {
        html += `<div style="text-align: center; font-size: 0.9rem; color: #6c757d; margin-bottom: 10px;">${escapeHtml(listing.subcategory)}</div>`;
    }

    // Title (centered, under subcategory)
    html += `<h3 style="text-align: center; margin-bottom: 10px;">${escapeHtml(listing.title)}</h3>`;

    // Price and condition (centered, under title)
    if (listing.price || listing.condition) {
        html += `<div style="text-align: center; margin-bottom: 15px;">`;
        if (listing.price) {
            let displayPrice = listing.price;
            // Add $ if it's a number and doesn't already have currency symbol
            if (/^\d+(\.\d{2})?$/.test(listing.price.trim())) {
                displayPrice = `$${listing.price}`;
            }
            html += `<span class="listing-price">${escapeHtml(displayPrice)}</span>`;
        }
        if (listing.condition) {
            html += `<span class="listing-condition">${escapeHtml(listing.condition)}</span>`;
        }
        html += `</div>`;
    }

    // Images (all images, centered and stacked)
    if (listing.images && listing.images.length > 0) {
        html += `<div class="listing-images" style="text-align: center;">`;
        html += `<strong>🖼️ Images (${listing.images.length}):</strong>`;
        html += `<div class="listing-images-grid">`;
        listing.images.forEach((imageUrl, imgIndex) => {
            html += `<div class="listing-image" onclick="openImageModal('${escapeHtml(imageUrl)}')">`;
            html += `<img src="${escapeHtml(imageUrl)}" alt="Listing image ${imgIndex + 1}" loading="lazy" onerror="this.style.display='none'">`;
            html += `</div>`;
        });
        html += `</div></div>`;
    }

    // Location info (centered, under images)
    if (listing.locationType) {
        html += `<div style="text-align: center; margin-top: 15px;">`;
        html += `<span class="listing-location-type ${listing.locationType}">${listing.locationType.toUpperCase()}</span>`;
        if (listing.location) {
            html += ` 📍 ${escapeHtml(listing.location)}`;
        }
        if (listing.zipCode && listing.locationType === 'local') {
            html += ` 📮 ${escapeHtml(listing.zipCode)}`;
        }
        html += `</div>`;
    }

    // Description
    html += `<p class="listing-description" style="white-space: pre-wrap; margin-top: 20px;">${escapeHtml(listing.description)}</p>`;

    // Meta information (excluding "Posted by" since it's their own listing)
    html += `<div class="listing-meta">`;
    if (listing.link) {
        html += `<p><strong>🔗 Store/Product:</strong><br><a href="${escapeHtml(listing.link)}" target="_blank" rel="noopener noreferrer">${escapeHtml(listing.link)}</a></p>`;
    }
    if (listing.contact) {
        html += `<p><strong>📞 Contact:</strong><br><span style="white-space: pre-wrap;">${escapeHtml(listing.contact)}</span></p>`;
    }
    html += `</div>`;

    // Posted date (centered, outside of listing-meta)
    html += `<div style="text-align: center; color: #6c757d; font-size: 0.9rem; margin: 15px 0;">`;
    html += `<div>Posted:</div>`;
    html += `<div>${new Date(listing.timestamp).toLocaleString()}</div>`;
    html += `</div>`;

    // Views (centered)
    if (listing.views) {
        html += `<div class="listing-views" style="text-align: center;">👁️ ${listing.views} views</div>`;
    }

    // Edit and Delete buttons (centered, side by side)
    html += `<div style="text-align: center; margin-top: 20px;">`;
    html += `<button onclick="showEditListingDialog(${JSON.stringify(listing).replace(/"/g, '&quot;')})" class="btn secondary" style="margin-right: 10px;">Edit</button>`;
    html += `<button onclick="deleteListing('${listing.id}')" class="btn danger">Delete</button>`;
    html += `</div>`;

    html += `</div>`;

    // Replace the listings list with the full view
    const listEl = document.getElementById('my-listings-list');
    listEl.innerHTML = html;
}

// Go back to my listings view
function goBackToMyListings() {
    displayMyListings(currentMyListings);
}

// Edit listing function
function editListing(listingId) {
    // Find the listing
    socket.emit('sendAPIRequest', {
        type: 'api_shopping_listings',
        data: {}
    }, (response) => {
        if (response.success && response.data && response.data.listings) {
            const listing = response.data.listings.find(l => l.id === listingId);
            if (listing && (listing.walletAddress === currentWallet.address || listing.postedBy === currentWallet.address)) {
                showEditListingDialog(listing);
            } else {
                showToast('Listing not found or permission denied', 'error');
            }
        } else {
            showToast('Failed to load listing', 'error');
        }
    });
}

// Show enhanced edit listing dialog
let currentEditingListing = null;

function showEditListingDialog(listing) {
    currentEditingListing = listing;

    // Initialize enhanced form
    initializeEditForm();

    // Populate the form with current values
    document.getElementById('edit-listing-title').value = listing.title || '';
    document.getElementById('edit-listing-description').value = listing.description || '';

    // Category
    if (listing.category) {
        document.getElementById('edit-listing-category').value = listing.category;
        updateEditSubcategories();
        if (listing.subcategory) {
            document.getElementById('edit-listing-subcategory').value = listing.subcategory;
        }
    }

    // Price and condition
    document.getElementById('edit-listing-price').value = listing.price || '';
    document.getElementById('edit-listing-condition').value = listing.condition || '';

    // Location
    document.getElementById('edit-listing-location-type').value = listing.locationType || '';
    toggleEditLocalFields();
    document.getElementById('edit-listing-zipcode').value = listing.zipCode || '';
    document.getElementById('edit-listing-location').value = listing.location || '';

    // Images
    displayEditImages(listing.images || []);

    // Additional info
    document.getElementById('edit-listing-tags').value = listing.tags ? listing.tags.join(', ') : '';
    document.getElementById('edit-listing-link').value = listing.link || '';
    document.getElementById('edit-listing-contact').value = listing.contact || '';

    // Show the modal
    document.getElementById('edit-listing-modal').style.display = 'flex';

    // Focus on the title input
    document.getElementById('edit-listing-title').focus();
}

// Initialize edit form features
function initializeEditForm() {
    // Initialize category dropdown
    const categorySelect = document.getElementById('edit-listing-category');
    if (categorySelect) {
        categorySelect.innerHTML = '<option value="">Select a category...</option>';
        Object.keys(SHOPPING_CATEGORIES).forEach(category => {
            const option = document.createElement('option');
            option.value = category;
            option.textContent = category;
            categorySelect.appendChild(option);
        });

        // Add change event for subcategory
        categorySelect.onchange = updateEditSubcategories;
    }

    // Initialize location type change handler
    const locationTypeSelect = document.getElementById('edit-listing-location-type');
    if (locationTypeSelect) {
        locationTypeSelect.onchange = toggleEditLocalFields;
    }

    // Initialize image upload handlers
    initializeEditImageUpload();
}

// Update subcategories for edit form
function updateEditSubcategories() {
    const categorySelect = document.getElementById('edit-listing-category');
    const subcategorySelect = document.getElementById('edit-listing-subcategory');

    if (!categorySelect || !subcategorySelect) return;

    const selectedCategory = categorySelect.value;
    subcategorySelect.innerHTML = '<option value="">Select a subcategory...</option>';

    if (selectedCategory && SHOPPING_CATEGORIES[selectedCategory]) {
        SHOPPING_CATEGORIES[selectedCategory].forEach(subcategory => {
            const option = document.createElement('option');
            option.value = subcategory;
            option.textContent = subcategory;
            subcategorySelect.appendChild(option);
        });
    }
}

// Toggle local fields for edit form
function toggleEditLocalFields() {
    const locationTypeSelect = document.getElementById('edit-listing-location-type');
    const localFields = document.getElementById('edit-local-fields');

    if (!locationTypeSelect || !localFields) return;

    if (locationTypeSelect.value === 'local') {
        localFields.style.display = 'block';
        document.getElementById('edit-listing-zipcode').required = true;
    } else {
        localFields.style.display = 'none';
        document.getElementById('edit-listing-zipcode').required = false;
    }
}

// Initialize edit image upload functionality
function initializeEditImageUpload() {
    const uploadBtn = document.getElementById('edit-upload-file-btn');
    const addUrlBtn = document.getElementById('edit-add-url-btn');
    const fileInput = document.getElementById('edit-image-file-input');

    if (uploadBtn && fileInput) {
        uploadBtn.onclick = () => fileInput.click();
        fileInput.onchange = (e) => handleEditImageUpload(e);
    }

    if (addUrlBtn) {
        addUrlBtn.onclick = addEditImageURL;
    }
}

// Display images in edit form
function displayEditImages(images) {
    const previewContainer = document.getElementById('edit-image-preview');
    if (!previewContainer) return;

    previewContainer.innerHTML = '';

    images.forEach((imageUrl, index) => {
        addEditImagePreview(imageUrl, null);
    });
}

// Handle image upload for edit form
async function handleEditImageUpload(event) {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    const previewContainer = document.getElementById('edit-image-preview');
    if (!previewContainer) return;

    for (const file of files) {
        if (previewContainer.children.length >= 10) {
            showToast('Maximum 10 images allowed', 'error');
            break;
        }

        if (!file.type.startsWith('image/')) {
            showToast(`${file.name} is not an image file`, 'error');
            continue;
        }

        if (file.size > 32 * 1024 * 1024) { // 32MB limit
            showToast(`${file.name} is too large (max 32MB)`, 'error');
            continue;
        }

        try {
            showToast('Uploading image...', 'info');

            // Convert to base64
            const base64 = await fileToBase64(file);

            // Upload to imgbb
            const imageData = await uploadToImgbb(base64);

            if (imageData) {
                addEditImagePreview(imageData.url, imageData.deleteUrl);
                showToast('Image uploaded successfully!', 'success');
            } else {
                showToast('Failed to upload image', 'error');
            }
        } catch (error) {
            showToast(`Error uploading ${file.name}: ${error.message}`, 'error');
        }
    }

    // Clear the file input
    event.target.value = '';
}

// Add image URL for edit form
function addEditImageURL() {
    const url = prompt('Enter image URL:');
    if (!url || !url.trim()) return;

    const trimmedUrl = url.trim();

    // Basic URL validation
    if (!trimmedUrl.startsWith('http://') && !trimmedUrl.startsWith('https://')) {
        showToast('Please enter a valid URL starting with http:// or https://', 'error');
        return;
    }

    const previewContainer = document.getElementById('edit-image-preview');
    if (!previewContainer) return;

    if (previewContainer.children.length >= 10) {
        showToast('Maximum 10 images allowed', 'error');
        return;
    }

    addEditImagePreview(trimmedUrl, null);
}

// Add image preview for edit form
function addEditImagePreview(imageUrl, deleteUrl) {
    const previewContainer = document.getElementById('edit-image-preview');
    if (!previewContainer) return;

    const previewDiv = document.createElement('div');
    previewDiv.className = 'image-preview';
    previewDiv.innerHTML = `
        <img src="${escapeHtml(imageUrl)}" alt="Preview" loading="lazy" onerror="this.style.display='none'">
        <button type="button" class="remove-image" onclick="removeEditImagePreview(this)">×</button>
    `;

    // Store the URLs as data attributes
    previewDiv.dataset.imageUrl = imageUrl;
    if (deleteUrl) {
        previewDiv.dataset.deleteUrl = deleteUrl;
    }

    previewContainer.appendChild(previewDiv);
}

// Remove image preview for edit form
function removeEditImagePreview(button) {
    const previewDiv = button.parentElement;
    previewDiv.remove();
}

function hideEditListingModal() {
    document.getElementById('edit-listing-modal').style.display = 'none';
    currentEditingListing = null;
}

// Enhanced save listing changes function
function saveEnhancedListingChanges() {
    if (!currentEditingListing) return;

    // Basic fields
    const title = document.getElementById('edit-listing-title').value.trim();
    const description = document.getElementById('edit-listing-description').value.trim();
    const category = document.getElementById('edit-listing-category').value;
    const subcategory = document.getElementById('edit-listing-subcategory').value;
    const price = document.getElementById('edit-listing-price').value.trim();
    const condition = document.getElementById('edit-listing-condition').value;
    const locationType = document.getElementById('edit-listing-location-type').value;
    const location = document.getElementById('edit-listing-location').value.trim();
    const zipCode = document.getElementById('edit-listing-zipcode').value.trim();
    const tags = document.getElementById('edit-listing-tags').value.trim();
    const link = document.getElementById('edit-listing-link').value.trim();
    const contact = document.getElementById('edit-listing-contact').value.trim();

    // Validate required fields
    if (!title || !description || !category || !locationType) {
        showToast('Please complete all required fields', 'error');
        return;
    }

    // Validate local listings require ZIP code
    if (locationType === 'local' && !zipCode) {
        showToast('ZIP code is required for local listings', 'error');
        return;
    }

    // Collect images
    const imagePreviewContainer = document.getElementById('edit-image-preview');
    const images = [];
    const imageDeleteUrls = [];

    if (imagePreviewContainer) {
        const previews = imagePreviewContainer.querySelectorAll('.image-preview');
        previews.forEach(preview => {
            const imageUrl = preview.dataset.imageUrl;
            const deleteUrl = preview.dataset.deleteUrl;
            if (imageUrl) {
                images.push(imageUrl);
                if (deleteUrl) {
                    imageDeleteUrls.push(deleteUrl);
                }
            }
        });
    }

    // Process tags
    const tagsArray = tags ? tags.split(',').map(tag => tag.trim()).filter(tag => tag.length > 0) : [];

    // Submit enhanced edit
    socket.emit('sendAPIRequest', {
        type: 'api_shopping_edit_listing',
        data: {
            id: currentEditingListing.id,
            title: title,
            description: description,
            category: category,
            subcategory: subcategory,
            price: price,
            condition: condition,
            locationType: locationType,
            location: location,
            zipCode: zipCode,
            images: images,
            imageDeleteUrls: imageDeleteUrls,
            tags: tagsArray,
            link: link,
            contact: contact,
            walletAddress: currentWallet.address,
            version: 2
        }
    }, (response) => {
        if (response.success) {
            showToast('Listing updated successfully!', 'success');
            hideEditListingModal();
            loadMyListings(); // Refresh the list
        } else {
            showToast(`Failed to update listing: ${response.error}`, 'error');
        }
    });
}

// Keep old function for backward compatibility
function saveListingChanges() {
    saveEnhancedListingChanges();
}

// Delete listing function
function deleteListing(listingId, listingTitle) {
    if (!confirm(`Are you sure you want to delete "${listingTitle}"?\n\nThis action cannot be undone.`)) {
        return;
    }
    
    socket.emit('sendAPIRequest', {
        type: 'api_shopping_delete_listing',
        data: {
            id: listingId,
            walletAddress: currentWallet.address
        }
    }, (response) => {
        if (response.success) {
            showToast('Listing deleted successfully!', 'success');
            loadMyListings(); // Refresh the list
        } else {
            showToast(`Failed to delete listing: ${response.error}`, 'error');
        }
    });
}

// Helper function to escape HTML
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Check if wallet is genesis and show/hide genesis functions
function checkGenesisWallet() {
    const GENESIS_ADDRESS = "106F52B72184F3B928FA9D7C1A3A2433BA";
    const genesisActions = document.getElementById('genesis-actions');
    
    if (currentWallet && currentWallet.address === GENESIS_ADDRESS) {
        genesisActions.style.display = 'block';
    } else {
        genesisActions.style.display = 'none';
    }
}

// Staking functionality
let selectedStakingPeriod = null;

// Add event listeners for staking period selection
document.addEventListener('DOMContentLoaded', function() {
    const periodOptions = document.querySelectorAll('.period-option');
    const stakeAmountInput = document.getElementById('stake-amount');
    
    periodOptions.forEach(option => {
        option.addEventListener('click', function() {
            // Remove active class from all options
            periodOptions.forEach(opt => opt.classList.remove('active'));
            // Add active class to selected option
            this.classList.add('active');
            
            selectedStakingPeriod = {
                duration: parseInt(this.dataset.duration),
                reward: parseFloat(this.dataset.reward),
                name: this.dataset.name
            };
            
            document.getElementById('selected-period').textContent = `Selected: ${selectedStakingPeriod.name}`;
            document.querySelector('.staking-form').style.display = 'block';
            
            updateStakingSummary();
        });
    });
    
    stakeAmountInput.addEventListener('input', updateStakingSummary);
    
    document.getElementById('confirm-stake-btn').addEventListener('click', confirmStaking);
});

function updateStakingSummary() {
    if (!selectedStakingPeriod) return;
    
    const amount = parseFloat(document.getElementById('stake-amount').value) || 0;
    const reward = amount * selectedStakingPeriod.reward / 100;
    const total = amount + reward;
    const unlockDate = new Date(Date.now() + selectedStakingPeriod.duration);
    
    document.getElementById('summary-amount').textContent = `${amount.toFixed(8)} TheeCoin`;
    document.getElementById('summary-reward').textContent = `${reward.toFixed(8)} TheeCoin`;
    document.getElementById('summary-total').textContent = `${total.toFixed(8)} TheeCoin`;
    document.getElementById('summary-unlock').textContent = unlockDate.toLocaleString();
    
    if (amount > 0) {
        document.getElementById('staking-summary').style.display = 'block';
    } else {
        document.getElementById('staking-summary').style.display = 'none';
    }
}

function confirmStaking() {
    if (!currentWallet) {
        showToast('Please load a wallet first', 'error');
        return;
    }
    
    if (!selectedStakingPeriod) {
        showToast('Please select a staking period', 'error');
        return;
    }
    
    const amount = parseFloat(document.getElementById('stake-amount').value);
    if (!amount || amount <= 0) {
        showToast('Please enter a valid amount', 'error');
        return;
    }
    
    if (!confirm(`Confirm staking ${amount} TheeCoin for ${selectedStakingPeriod.name}?`)) {
        return;
    }
    
    showLoading('Staking coins...');
    
    socket.emit('sendAPIRequest', {
        type: 'api_stake_coins',
        data: {
            walletAddress: currentWallet.address,
            amount: amount,
            duration: selectedStakingPeriod.duration,
            rewardPercentage: selectedStakingPeriod.reward
        }
    }, (response) => {
        hideLoading();
        
        if (response.success) {
            showToast(`Successfully staked ${amount} TheeCoin for ${selectedStakingPeriod.name}!`, 'success');
            document.getElementById('stake-amount').value = '';
            document.getElementById('staking-summary').style.display = 'none';
            selectedStakingPeriod = null;
            document.querySelectorAll('.period-option').forEach(opt => opt.classList.remove('active'));
            document.querySelector('.staking-form').style.display = 'none';
            // Refresh balance after a small delay to ensure transaction has processed
            setTimeout(() => {
                refreshBalance();
            }, 1000);
            loadUserStakes(); // Refresh stakes list to show new stake
        } else {
            showToast(`Staking failed: ${response.error}`, 'error');
        }
    });
}

// Load and display user stakes
function loadUserStakes() {
    if (!currentWallet) {
        showToast('Please load a wallet first', 'error');
        return;
    }
    
    const loadingEl = document.getElementById('stakes-loading');
    const contentEl = document.getElementById('stakes-content');
    const emptyEl = document.getElementById('stakes-empty');
    
    loadingEl.style.display = 'block';
    contentEl.style.display = 'none';
    emptyEl.style.display = 'none';
    
    socket.emit('sendAPIRequest', {
        type: 'api_get_stakes',
        data: {
            walletAddress: currentWallet.address
        }
    }, (response) => {
        loadingEl.style.display = 'none';
        
        if (response.success && response.data && response.data.stakes) {
            if (response.data.stakes.length === 0) {
                emptyEl.style.display = 'block';
            } else {
                contentEl.style.display = 'block';
                displayUserStakes(response.data.stakes);
            }
        } else {
            emptyEl.style.display = 'block';
            showToast('Failed to load stakes', 'error');
        }
    });
}

function displayUserStakes(stakes) {
    const listEl = document.getElementById('stakes-list');
    
    listEl.innerHTML = stakes.map(stake => {
        const unlockDate = new Date(stake.unlockTime);
        const isUnlocked = Date.now() >= stake.unlockTime;
        const status = isUnlocked ? "✅ UNLOCKED" : "🔒 LOCKED";
        const reward = stake.amount * stake.rewardPercentage / 100;
        const total = stake.amount + reward;
        
        return `
            <div class="stake-item">
                <div class="stake-header">
                    <h4>${stake.amount} TheeCoin - ${stake.period}</h4>
                    <div class="stake-status ${isUnlocked ? 'unlocked' : 'locked'}">${status}</div>
                </div>
                <div class="stake-details">
                    <div class="stake-info">
                        <span>Staked: ${new Date(stake.stakeTime).toLocaleString()}</span>
                        <span>Unlock: ${unlockDate.toLocaleString()}</span>
                        <span>Reward: ${stake.rewardPercentage}% (${reward.toFixed(8)} TheeCoin)</span>
                        <span>Total Return: ${total.toFixed(8)} TheeCoin</span>
                    </div>
                    ${isUnlocked ? `
                        <div class="stake-actions centered">
                            <button class="btn primary" onclick="unstakeCoins('${stake.id}', ${total})">
                                Unstake (${total.toFixed(8)} TheeCoin)
                            </button>
                        </div>
                    ` : `
                        <div class="lock-info">
                            <span>🔒 Locked until ${unlockDate.toLocaleDateString()}</span>
                        </div>
                        <div class="stake-actions centered">
                            <button class="btn secondary" onclick="changeStaking('${stake.id}', '${stake.period}', ${stake.rewardPercentage})">
                                Change Staking
                            </button>
                            <button class="btn warning" onclick="unlockCoins('${stake.id}', ${stake.amount})">
                                Unlock TheeCoin
                            </button>
                        </div>
                    `}
                </div>
            </div>
        `;
    }).join('');
}

function unstakeCoins(stakeId, totalAmount) {
    if (!confirm(`Confirm unstaking? You will receive ${totalAmount.toFixed(8)} TheeCoin.`)) {
        return;
    }
    
    showLoading('Unstaking coins...');
    
    socket.emit('sendAPIRequest', {
        type: 'api_unstake_coins',
        data: {
            walletAddress: currentWallet.address,
            stakeId: stakeId
        }
    }, (response) => {
        hideLoading();
        
        if (response.success) {
            showToast(`Successfully unstaked! Received ${response.data.totalAmount.toFixed(8)} TheeCoin.`, 'success');
            loadUserStakes(); // Refresh the stakes list
            // Refresh balance after a small delay to ensure transaction has processed
            setTimeout(() => {
                refreshBalance();
            }, 1000);
        } else {
            showToast(`Unstaking failed: ${response.error}`, 'error');
        }
    });
}

// Change staking period for an existing stake
function changeStaking(stakeId, currentPeriod, currentReward) {
    // Show staking period selection modal
    showStakingPeriodModal(stakeId, currentPeriod, currentReward);
}

// Unlock coins early with time-based rewards
function unlockCoins(stakeId, amount) {
    if (!currentWallet) {
        showToast('Please load a wallet first', 'error');
        return;
    }
    
    if (!confirm(`Are you sure you want to unlock your ${amount} TheeCoin early?\n\nYou only receive rewards based on the time you've staked\nIf you haven't staked for a full week, you will get no reward`)) {
        return;
    }
    
    showLoading('Unlocking coins...');
    
    socket.emit('sendAPIRequest', {
        type: 'api_unlock_coins',
        data: {
            walletAddress: currentWallet.address,
            stakeId: stakeId
        }
    }, (response) => {
        hideLoading();
        
        if (response.success) {
            const data = response.data;
            if (data.rewardAmount > 0) {
                showToast(`Successfully unlocked ${data.originalAmount} TheeCoin + ${data.rewardAmount.toFixed(8)} reward (${data.earnedRewardPercentage}%) after ${data.timeStaked} days!`, 'success');
            } else {
                showToast(`Successfully unlocked ${data.originalAmount} TheeCoin. No rewards earned (staked for ${data.timeStaked} days).`, 'success');
            }
            refreshBalance();
            loadUserStakes();
        } else {
            showToast(`Unlock failed: ${response.error}`, 'error');
        }
    });
}

// Show modal for changing staking period
function showStakingPeriodModal(stakeId, currentPeriod, currentReward) {
    const stakingPeriods = [
        { name: "1 week", duration: 604800000, reward: 2.08 },
        { name: "2 weeks", duration: 1209600000, reward: 4.16 },
        { name: "1 month", duration: 2592000000, reward: 8.33 },
        { name: "3 months", duration: 7776000000, reward: 25 },
        { name: "6 months", duration: 15552000000, reward: 50 },
        { name: "1 year", duration: 31536000000, reward: 100 }
    ];
    
    const modalHtml = `
        <div class="modal-overlay" id="change-staking-modal">
            <div class="modal-content">
                <h3>Change Staking Period</h3>
                <p>Current: ${currentPeriod} (${currentReward}% reward)</p>
                <p>Select new staking period:</p>
                <div class="staking-periods">
                    ${stakingPeriods.map(period => `
                        <div class="period-option ${period.name === currentPeriod ? 'current' : ''}" 
                             onclick="selectNewPeriod('${stakeId}', ${period.duration}, ${period.reward}, '${period.name}')">
                            <div class="period-name">${period.name}</div>
                            <div class="period-reward">${period.reward}% reward</div>
                        </div>
                    `).join('')}
                </div>
                <div class="modal-actions">
                    <button class="btn secondary" onclick="closeStakingModal()">Cancel</button>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHtml);
}

// Select new staking period
function selectNewPeriod(stakeId, newDuration, newReward, newPeriodName) {
    if (!confirm(`Change staking period to ${newPeriodName} (${newReward}% reward)?`)) {
        return;
    }
    
    showLoading('Changing staking period...');
    closeStakingModal();
    
    socket.emit('sendAPIRequest', {
        type: 'api_change_staking',
        data: {
            walletAddress: currentWallet.address,
            stakeId: stakeId,
            newDuration: newDuration,
            newRewardPercentage: newReward
        }
    }, (response) => {
        hideLoading();
        
        if (response.success) {
            if (response.data.status === 'past_period') {
                // They've already staked past the new period
                if (confirm(`${response.data.message}\n\nWould you like to accept the ${response.data.newPeriod} reward and receive your coins immediately?`)) {
                    // Process as early completion with the new period's reward
                    unlockCoins(stakeId, 0); // Amount doesn't matter for unlock
                }
            } else {
                showToast(`Staking period changed to ${newPeriodName}!`, 'success');
                loadUserStakes(); // Refresh stakes list
            }
        } else {
            showToast(`Failed to change staking period: ${response.error}`, 'error');
        }
    });
}

// Close staking modal
function closeStakingModal() {
    const modal = document.getElementById('change-staking-modal');
    if (modal) {
        modal.remove();
    }
}

// Recovery functionality (Genesis only)
function confirmRecovery() {
    const GENESIS_ADDRESS = "106F52B72184F3B928FA9D7C1A3A2433BA";
    
    if (!currentWallet || currentWallet.address !== GENESIS_ADDRESS) {
        showToast('Access denied. This function is restricted to Genesis wallet only.', 'error');
        return;
    }
    
    const fromAddress = document.getElementById('recovery-from').value.trim();
    const toAddress = document.getElementById('recovery-to').value.trim();
    
    if (!fromAddress || fromAddress.length !== 34) {
        showToast('Please enter a valid source wallet address', 'error');
        return;
    }
    
    if (!toAddress || toAddress.length !== 34) {
        showToast('Please enter a valid destination wallet address', 'error');
        return;
    }
    
    if (fromAddress === toAddress) {
        showToast('Source and destination addresses cannot be the same', 'error');
        return;
    }
    
    const confirmText = prompt('Type "CONFIRM" to proceed with recovery:');
    if (confirmText !== 'CONFIRM') {
        showToast('Recovery cancelled', 'info');
        return;
    }
    
    const finalConfirm = prompt('Type "RECOVERY" to finalize:');
    if (finalConfirm !== 'RECOVERY') {
        showToast('Recovery cancelled', 'info');
        return;
    }
    
    showLoading('Processing recovery...');
    
    socket.emit('sendAPIRequest', {
        type: 'api_recover_coins',
        data: (() => {
            // Create cryptographic proof instead of sending private key
            const challenge = Date.now().toString() + Math.random().toString();
            const message = `genesis_recovery_${fromAddress}_${toAddress}_${currentWallet.address}_${challenge}`;
            const combinedData = message + currentWallet.privateKey;
            const genesisProof = CryptoJS.SHA256(combinedData).toString();
            
            return {
                fromAddress: fromAddress,
                toAddress: toAddress,
                genesisAddress: currentWallet.address,
                challenge: challenge,
                genesisProof: genesisProof // Cryptographic proof, not private key
            };
        })()
    }, (response) => {
        hideLoading();
        
        if (response.success) {
            showToast(`Recovery completed! ${response.data.amount} TheeCoin recovered.`, 'success');
            document.getElementById('recovery-from').value = '';
            document.getElementById('recovery-to').value = '';
        } else {
            showToast(`Recovery failed: ${response.error}`, 'error');
        }
    });
}

// Close wallet and return to setup screen
function closeWallet() {
    if (confirm('Are you sure? Ensure you saved the mnemonic or private key!')) {
        // Clean up any local data first
        currentWallet = null;
        currentMnemonic = null;
        miningActive = false;
        selectedCrypto = null;
        currentPayment = null;
        
        // Simply refresh the page to reset everything (this only affects the browser)
        window.location.reload(true); // Force reload from server
    }
}

// Note: Genesis wallet checking is now integrated into updateWalletDisplay()
// and stake loading is integrated into showSection()

// Initialize with setup section
showSection('setup');

Instructions:

1. Extract the TheeCoin_Linux.tar.gz file into a new folder named TheeCoin
2. Click on the TheeCoin_Linux.desktop to run TheeCoin Wallet

Some versions of linux may require you to follow these instructions instead:
1. Open the terminal or terminal emulator
2. Navigate to where you extracted the contents of the TheeCoin_Linux.tar.gz file
3. Once you are within the TheeCoin folder, run bash run.sh in the terminal window
4. TheeCoin Wallet should then run successfully

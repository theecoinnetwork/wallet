#!/usr/bin/env node

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

// Calculate Windows wallet hash exactly the same way as client.js does
function calculateWindowsWalletHash() {
  try {
    console.log('🔍 Calculating Windows wallet hash exactly like client.js...\n');
    
    // Use current directory (same as process.cwd() in client.js)
    const walletDir = process.cwd();
    console.log(`Directory: ${walletDir}`);
    
    // Get all .js files and sort them (same as client.js)
    const jsFiles = fs.readdirSync(walletDir)
      .filter(file => file.endsWith('.js'))
      .sort();
    
    console.log(`\nJS files found (${jsFiles.length} files):`);
    jsFiles.forEach((file, index) => {
      console.log(`  ${index + 1}. ${file}`);
    });
    
    if (jsFiles.length === 0) {
      throw new Error('No wallet JS files found');
    }

    // Combine all file contents (same as client.js)
    let combinedContent = '';
    console.log('\nReading files:');
    
    for (const file of jsFiles) {
      try {
        const filePath = path.join(walletDir, file);
        const content = fs.readFileSync(filePath, 'utf8');
        combinedContent += content;
        console.log(`  ✅ ${file}: ${content.length} characters`);
      } catch (fileErr) {
        console.log(`  ❌ ${file}: Error - ${fileErr.message}`);
      }
    }

    // Calculate SHA-256 hash (same as client.js)
    const hash = crypto.createHash('sha256').update(combinedContent).digest('hex');
    
    console.log(`\n📊 Results:`);
    console.log(`Total combined content: ${combinedContent.length} characters`);
    console.log(`Windows wallet hash: ${hash}`);
    
    return hash;
  } catch (err) {
    return null;
  }
}

// Check what hash is expected in hash-config.js files
function checkExpectedHashes() {
  console.log('\n🔍 Checking expected hashes in hash-config.js files...\n');
  
  const hashConfigPaths = [
    '../node/hash-config.js',
    '../safe-node/hash-config.js'
  ];
  
  for (const configPath of hashConfigPaths) {
    try {
      const fullPath = path.resolve(configPath);
      if (fs.existsSync(fullPath)) {
        const content = fs.readFileSync(fullPath, 'utf8');
        
        // Extract windows hash from the file
        const windowsHashMatch = content.match(/'windows':\s*'([a-f0-9]+)'/);
        if (windowsHashMatch) {
          console.log(`${configPath}:`);
          console.log(`  Windows hash: ${windowsHashMatch[1]}`);
        } else {
          console.log(`${configPath}: Windows hash not found`);
        }
      } else {
        console.log(`${configPath}: File not found`);
      }
    } catch (err) {
      console.log(`${configPath}: Error reading - ${err.message}`);
    }
  }
}

// Main execution
console.log('🚀 Windows Wallet Hash Checker');
console.log('================================\n');

const calculatedHash = calculateWindowsWalletHash();
checkExpectedHashes();

if (calculatedHash) {
  console.log('\n🎯 Summary:');
  console.log(`Calculated hash: ${calculatedHash}`);
  console.log('\nCompare this with the hashes shown above from hash-config.js files.');
  console.log('If they don\'t match, that\'s why the wallet is being rejected!');
} else {
  console.log('\n❌ Failed to calculate hash');
}

TheeCoin Wallet for Windows
====================================

Usage Instructions:
1. Extract all files to any folder on your computer
2. Double-click "TheeCoin.exe" or run "run.bat" in command prompt
3. The wallet will then run

No Installation Required:
- This doesn't require installation
- All files are contained in this folder
- Your wallet data will be stored in the "wallets" subfolder
- You can move this entire folder anywhere on your computer

NOTE: You must have Node.js version 18 or later installed
If you need to download or update Node.js, go to this link
https://nodejs.org/en/download (Official Node.js website)
Scroll to the bottom of the page and choose architecture
Choose x86, x64 or ARM64 and then get it's .msi installer

If you don't know which one your device is, just do this:
1. Go into your system settings
2. Go to About (System > About)
3. Look at System type

System Requirements:
- Windows XP or later
- 2 GB RAM minimum
- 10 MB free disk space

Files Included:
- All wallet JavaScript files
- Configuration files (*.pem, *.json)
- Business integration tools
- Web interface files
- Empty wallets folder for your wallet data
- TheeCoin.exe launcher
- Alternative run.bat launcher